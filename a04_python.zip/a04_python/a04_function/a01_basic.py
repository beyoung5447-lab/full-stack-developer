'''
# 함수(function)
1. 특정 값을 넣으면(input), 정해진 처리를 거쳐(process), 결과값을 돌려주는(output)
기능이 함수라고 합니다.
2. 존재 이유(가장 중요) : 코드의 재활용성을 높여줍니다.(똑같은 코드를 수백 번 반복해서
작성할 필요 없이, 함수 이름만 부르면 됩니다!!)
- 비유컨데
자판기로 이해해 봅시다
동전과 버튼(매개변수/input) : 500원을 넣고 콜라 버튼을 누른다.
내부 처리(프로세스) : 기계 안에서 금액을 확인하고 캔을 굴려 떨어뜨린다.(우리는 이 복잡한
과정을 몰라도 자판기를 쓸 수 있습니다.)
나온 음료수(리턴값/Output) : 최종적으로 콜라가 나온다.
3. 파이썬 함수의 2가지 종류
   1) 내장 함수(Built-in Function) : 파이썬이 미리 만들어둔 자판기들
      print(), input(), int(), float(), len() 등
   2) 사용자 정의 함수(User-defined Function) : 우리가 직접 입맛대로 만드는 자판기
      def 키워드를 사용하여 직접 규칙을 만듭니다.
4. 기본 형식
    1) 함수 정의하기(만들기)
       def 함수명(매개변수1, 매개변수2):
           # 프로세스 처리(실행할 코드)
           처리내용
           return 돌려줄데이터
    2) 함수 호출하기(사용하기)
       결과저장변수 = 함수명(데이터1, 데이터2)
'''
# 물건 구매 계산기(buyProd 함수)
# 함수 정의 : 가격(price)과 갯수(cnt)를 재료로 받습니다.
def buyProd(price, cnt):
    tot = price * cnt # 총비용 계산(프로세스)
    print(f'구매한 물건의 가격:{price}')
    print(f'구매한 물건의 갯수:{cnt}')
    print(f'계산된 총비용:{tot}')
    return tot   # 계산된 총비용(tot)을 함수를 호출한 곳으로 돌려줍니다.
# 함수 호출 : 함수를 3번 불렀지만, 코드는 아주 짧고 간결합니다.
ret01 = buyProd(3000,2)   # ret01 = 6000
print(f"리턴한 값1:{ret01}")
ret02 = buyProd(4000,4)   # ret02 = 16000
print(f"리턴한 값2:{ret02}")
ret03 = buyProd(5000,3)
print(f"리턴한 값3:{ret03}")
print(buyProd(5000,2))  # print(10000)
'''
나만의 마법 믹서기 (함수) 만들기!
여러분은 과일과 갯수를 넣으면, 자동으로 맛있는 쥬스를 만들어주는 
'마법의 믹서기'를 발명했습니다. 이 믹서기를 파이썬 함수로 구현해 보세요!

[📝 퀘스트 요구사항]
함수 만들기: 믹서기의 이름(함수명)은 make_juice 입니다.
재료 넣기 (매개변수): 이 믹서기는 fruit(과일 이름)과 cnt(몇 잔)라는 두 개의 재료를 받습니다.
갈아버리기 (프로세스): 들어온 과일과 잔 수를 합쳐서 완성 메시지를 만듭니다. 
    (예: "사과 쥬스 3잔 완성!")
꺼내기 (리턴): 만들어진 완성 메시지를 믹서기 밖으로 뱉어냅니다(return).
작동시키기 (함수 호출): 믹서기에 '딸기'와 2잔을 넣고 돌린 결과를 화면에 출력해 보세요!
'''
# 함수정의 (매개변수로, 과일이름과 몇잔을 입력 하게 선언)
def make_juice(fruit, cnt):
    print(f'윙윙!! 믹서기에 {fruit}를 넣고 갈고 있습니다.!!')
    # 내부프로세스 처리 
    return_msg = f" {fruit} 쥬스 {cnt}잔 완성"
    # 결과값을 함수를 호출한 곳으로 돌려줌(리턴)
    return return_msg
# 함수 호출 및 결과값 변수에 할당.
my_order = make_juice('딸기',2)
# 리턴받은 데이터 출력
print("내가 받은 음료:", my_order)

# 1. 매개변수 처리 연습
#    함수를 make_pancake이라 하고, 매개변수를  토핑(topping)과  층수(layer)를 입력받아
#    요리사 : @@@@층짜리  @@@ 팬케이크를 굽기 시작합니다. 라고 출력만 되게 함수를
#    정의하고 매개변수를 전달 처리하게 하세요..
def make_pancake(layer, topping):
    print(f'요리사 : {layer}층짜리  {topping} 팬케이크를 굽기 시작합니다. ')

def product_buy(name, price, cnt):
    print(f"구매한 물건명:{name}")   
    print(f"구매한 가격:{price}")   
    print(f"구매한 갯수:{cnt}")   

make_pancake(4, '치즈토핑')
make_pancake(3, '고구마토핑')

product_buy('사과',3000,2)
product_buy('바나나',4000,3)
product_buy('딸기',12000,4)

def product_buyProc(name, price, cnt):
    print(f"구매한 물건명:{name}")   
    print(f"구매한 가격:{price}")   
    print(f"구매한 갯수:{cnt}") 
    tot = price*cnt  
    # 프로세스 처리 : 연산자를 이용해서 계산하거나, 조건문/반복문 원하는 결과 데이터
    print(f'총계[프로세스의 결과1]:{tot}')

product_buyProc('사과',3000,2)
# ex) 함수 calDem() 로  직사각형의 높이와 밑면을 매개변수로 입력받아서
#     출력  높이 : @@@,  밑면 : @@
#     프로세스 면적처리 : @@@  출력되게 하는 함수를 정의하고, 호출해보세요..
def calDem(height, base):
    print("# 입력된 직사각형 정보 #")
    print(f"높이 :{height}cm")
    print(f"밑면길이 :{base}cm")
    print("# 프로세스를 통한 처리 내용 #")
    dem = height*base
    print(f"면적:{dem}cm²")
calDem(5, 7)
calDem(15, 30)
calDem(7, 10)





def product_buyProcRet(name, price, cnt):
    print(f"구매한 물건명:{name}")   
    print(f"구매한 가격:{price}")   
    print(f"구매한 갯수:{cnt}") 
    tot = price*cnt  
    # 프로세스 처리 : 연산자를 이용해서 계산하거나, 조건문/반복문 원하는 결과 데이터
    print(f'총계[프로세스의 결과1]:{tot}')
    retVal = "구매한 물건은 "+name+"이고, 총비용은 "+str(tot)+"원입니다."
    return retVal

result1 = product_buyProcRet('사과',3000,2)
# result1 = "구매한 물건은 사과이고, 총비용은 6000 원입니다."

print("# 리턴 결과 내용 #\n", result1)

def retVal3000():    
    return 3000;

def retValName():
    return '홍길동';

val1 = retVal3000()
print(val1)

val2 = retValName()
print(val2)

print(retValName())
# ex1) add_TripleMoney() 매개변수로 money를 전달하면 3배의 금액을 리턴하는 함수를 정의하고
#  그 결과값을 변수에 할당 또는 바로 출력하게 하세요..
def add_TripleMoney(money):
    retVal = money*3
    return retVal
re01 = add_TripleMoney(3000)
print("리턴값을 변수에 할당:", re01)
print("리턴값을 함수로 바로 호출:", add_TripleMoney(4000))






