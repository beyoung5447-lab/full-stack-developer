'''
# 파이썬에서 사용되는 데이터 유형
1. 변수나 상수의 종류를 의미합니다. 그릇의 용도에 따라 국그릇, 밥그릇이 있듯이 변수에서
   할당하는 데이터 유형에 따라서 다양합니다.
2. 기본 데이터 유형
   1) 정수형
   var1 = 100
   2) 실수형
   var2 = 3.14
   3) 문자열형
   var3 = '파이썬'
   4) boolean형(True/False)
   var4 = True
   var5 = False
   var6 = var1>=100  : 비교연산식의 결과로 True가 할당됩니다.
3. 변수유형 확인 함수 : type()
   1) var1 = 100
      type(var1)
      <<class 'int'>> ==> 정수형일 때
'''
var1 = 100
var2 = 3.14
var3 = '파이썬'
var4 = var1>=100
print(f'var1:{var1}, 유형:{type(var1)}')
print(f'var1:{var2}, 유형:{type(var2)}')
print(f'var1:{var3}, 유형:{type(var3)}')
print(f'var1:{var4}, 유형:{type(var4)}')
# ex) input(), int() 를 이용해서 이름, 나이를 입력받아서
#     출력하되, 데이터 유형(type())도 확인하고, 성인여부 변수를 선언하여 18세이상 유무도 
#     출력  및 데이터 유형도 출력하세요..
'''
이름 : @@@  데이터유형 : @@@
나이 : @@@  데이터유형 : @@@
성인여부 : @@@  데이터유형 : @@@
'''
name = input("이름입력:")
age = int(input("나이입력:"))
isAdult = age>=18
print(f'''
이름 : {name} 데이터유형 : {type(name)}
나이 : {age} 데이터유형 : {type(age)}
성인여부 : {isAdult} 데이터유형 : {type(isAdult)}
''')