'''
# find() 함수..: 글자의 위치를 index로 리턴해준다.
'''
str1 = '난생 처음 공부하는 파이썬!!! 처음이라 신선하네요!! 그런데, 자바보다...'
posIdx = str1.find('처음')
print("처음이라는 단어의 첫번째 위치(index):", posIdx)
# ex) '사과 바나나 딸기 오렌지 수박'을 문자열로 선언하고, 딸기의 
# 처음 index 위치를 리턴하여 출력하세요
str2 = '사과 바나나 딸기 오렌지 수박'
posIdx2 = str2.find("딸기")
print("딸기의 index 위치:", posIdx2)

str1 = 'himan'
print('첫번째 문자:', str1[0])
print(str1[1])
print(str1[2])
print(str1[3])
print(str1[4])
print("마지막 문자:", str1[-1])
print(str1[-2])
print(str1[-3])
print(str1[-4])
# 2번째부터 4번째문자 추출 ==> 시작 0번 index 마지막 순서 1부터 시작해서 str1[1:4]
print("2번째부터 4번째 문자 추출:", str1[1:4])
# 시작부터 특정한 순서까지  ex) 처음부터 3번째까지 문자 추출 str1[:3]
print("처음부터 3번째까지 문자 추출:", str1[:3])
# 특정한 0부터 시작한 index위치부터 마지막까지  ex) 2번째부터 마지막 문자 추출 str1[1:]
print("2번째부터 마지막까지 문자 추출:", str1[1:])
# ex) 아래와 같은 주민번호에 생년의 년도와 일시를 추출하여  @@@년 @@월 @@일 생입니다. 라고
#  표현하세요
civilCode = '921212-2871621'
year = '19'+civilCode[0:2]
month = civilCode[2:4]
date = civilCode[4:6]
print(f"생일은 {year}년 {month}월 {date}일 입니다!!")
