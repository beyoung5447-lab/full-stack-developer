'''
# 증감연산자..
1. ++, --(파이썬에선 단항연산자 지원하지 않음.)
2. 변수명 += 증가단위
   변수명 -= 감소단위
'''
no = 1; print(no)
no = no + 1; print(no)
no += 1; print(no)
no = 10; print(no)
no = no - 1; print(no)
no -= 1; print(no)
# 2개이상 단위로 증감 처리..
no = 1; print(no)
no += 2; print(no)
no += 2; print(no)
no += 2; print(no)
no += 3; print(no)
no += 3; print(no)
no += 3; print(no)
# 5씩 감소 처리
no = 100; print(no)
no -= 5; print(no)
no -= 5; print(no)
no -= 5; print(no)
no -= 5; print(no)
# ex1) count 변수를 설정하여 10에서 부터 0까지 감소되는 처리를 해보세요
count = 10
print('카운트 다운', count); count-=1
print('카운트 다운', count); count-=1
print('카운트 다운', count); count-=1
print('카운트 다운', count); count-=1
print('카운트 다운', count); count-=1
print('카운트 다운', count); count-=1
print('카운트 다운', count); count-=1
print('카운트 다운', count); count-=1
print('카운트 다운', count); count-=1
print('카운트 다운', count); count-=1
print('카운트 다운', count); count-=1
# ex2) cnt변수로 구매물건이 1부터 10까지 갯수를 표현하고 바로 옆에 가격이 3000원일 때, 비용을
#   출력하세요
#   1개   3000
#   2개   6000
#   3개   9000
#   ...
price = 3000
cnt = 1
print(f'{cnt}개 {price*cnt}'); cnt+=1
print(f'{cnt}개 {price*cnt}'); cnt+=1
print(f'{cnt}개 {price*cnt}'); cnt+=1
print(f'{cnt}개 {price*cnt}'); cnt+=1
print(f'{cnt}개 {price*cnt}'); cnt+=1
print(f'{cnt}개 {price*cnt}'); cnt+=1
print(f'{cnt}개 {price*cnt}'); cnt+=1
print(f'{cnt}개 {price*cnt}'); cnt+=1
print(f'{cnt}개 {price*cnt}'); cnt+=1
print(f'{cnt}개 {price*cnt}'); cnt+=1