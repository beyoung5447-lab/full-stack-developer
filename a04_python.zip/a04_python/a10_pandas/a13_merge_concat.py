'''
# [판다스 실무] 데이터 합치기 완벽 마스터 (Merge & Concat)
## 1. 개요
데이터 분석 실무에서는 여러 파일이나 데이터베이스에 흩어진 데이터를 하나로 모으는 작업이 필수적입니다.
판다스(Pandas)에서는 데이터를 합치는 두 가지 핵심 도구로 `concat`과 `merge`를 제공합니다.
단순하게 서류를 스테이플러로 찍듯 이어 붙여야 할 때는 `concat`을 사용하고,
공통된 기준값을 바탕으로 지퍼를 채우듯 짝을 맞춰야 할 때는 `merge`를 사용합니다.
이 두 가지 개념을 완벽히 이해하면 실무 데이터 전처리 능력이 크게 향상됩니다.

## 2. 전문 용어로 알아보는 정확한 핵심 개념
**1) pd.concat() : 물리적 결합 (Concatenation)**
데이터의 내용이나 구조적 관계성을 따지지 않고 단순히 위아래(행)나 양옆(열)으로 이어 붙일 때 사용합니다.
* `objs` : 병합할 데이터프레임들을 리스트 형태로 전달합니다.
* `axis` : 결합 방향을 지정합니다. (0: 행 방향 병합, 1: 열 방향 병합)
* `ignore_index` : True 설정 시 기존 인덱스 번호를 무시하고 0부터 새롭게 인덱스를 부여합니다.

**2) pd.merge() : 관계형 병합 (Relational Join)**
데이터베이스의 Join 연산이나 엑셀의 VLOOKUP과 동일한 원리로 동작합니다.
단순 연결이 아닌, 두 데이터프레임이 공유하는 특정 열(Key)을 찾아 논리적으로 짝을 맞춥니다.

* `on` : 짝을 맞출 기준이 되는 공통 열(Key)의 이름입니다.
* `how` : 병합 방식(inner, outer, left, right)을 결정합니다.

## 3. 핵심 키워드 및 코드 최고의 암기법
코드를 작성할 때 헷갈리기 쉬운 속성들을 시각적 이미지로 연상하여 암기해 봅시다.
* **Concat 암기법: "콘(Con)크리트 블록 쌓기"**
* `axis=0` : 위에서 아래로 블록(행) 쌓기! (아파트 층수 올리기)
* `axis=1` : 양옆으로 나란히 기둥(열) 세우기! (옆집 건추하기)
* `ignore_index=True` : 기존 번호판이 지저분하면 무시하고 깔끔하게 새 번호판 발급!

* **Merge 암기법: "지퍼(on) 올리기"**
* `on="기준열"` : 지퍼의 양쪽 이빨입니다. 이빨(Key)이 맞아야 데이터가 채워집니다.
* `inner` (인싸) : 양쪽 모임에 다 있는 진짜 인싸(교집합)만 남깁니다.
* `outer` (아웃터) : 밖에서 서성이는 사람까지 전부 끌어안습니다(합집합). 빈자리는 결측치(NaN).
* `left` (레프트) : 무조건 왼쪽 그룹은 100% 생존합니다. 기준은 항상 왼쪽!
'''
import pandas as pd

# [예제 1] Concat (물리적 결합) : RPG 게임 서버 통합 작전
# 용의 기사단(1서버)과 마법의 숲(2서버) 데이터를 위아래(axis=0)로 합쳐 통합 서버를 구축합니다.
df_dragon = pd.DataFrame({'직업': ['전사', '기사'], '레벨': [99, 85]})
df_forest = pd.DataFrame({'직업': ['마법사', '힐러'], '레벨': [92, 88]})
print(df_dragon)
print(df_forest)
# 서버가 통합되면서 기존 유저 번호가 겹치지 않도록 ignore_index=True를 적용니다. (다시 통합하면 indexing 만듦)
result_guild = pd.concat([df_dragon,df_forest], axis=0, ignore_index=True)
print("통합된 최종 결과:\n",result_guild)

# 캐릭터 기본 스탯과 특수 능력치 데이터를 양옆(axis=1)으로 연결해 종합 상태창을 만듭니다.
df_basic = pd.DataFrame({'캐릭터명': ['전사', '마법사', '도적'], '체력(HP)': [1500, 800, 1000]})
df_special = pd.DataFrame({'마나(MP)': [300, 1500, 500], '필살기': ['파워스트라이크', '메테오', '암살']})
print(df_basic)
print(df_special)
result_stats = pd.concat([df_basic,df_special], axis=1)
print("캐릭터 종합 상태창\n", result_stats)
'''
### [초급 연습문제] 위즈덤 마트의 데이터 통합 작전

최근 사업이 확장되어 서울점과 수원점의 주문 데이터를 하나로 합치고,
상품의 기본 정보와 배송 정보를 나란히 연결해 종합 카탈로그를 만들어야 합니다.

**[문제 조건]**

1. 서울점(`df_seoul`)과 수원점(`df_suwon`)의 주문 데이터를 위아래(`axis=0`)로 합치고,
기존 인덱스를 무시하여 새롭게 번호를 부여하세요.
2. 상품 기본 정보(`df_prod_base`)와 배송 정보(`df_prod_ship`)를 양옆(`axis=1`)으로 연결해
최종 종합 카탈로그를 만드세요.
'''

import pandas as pd

# 1. 지점별 주문 데이터
df_seoul = pd.DataFrame({'고객명': ['김철수', '이영희'], '구매금액': [50000, 30000]})
df_suwon = pd.DataFrame({'고객명': ['박지성', '손흥민'], '구매금액': [75000, 120000]})

# 2. 상품 정보 데이터
df_prod_base = pd.DataFrame({'상품명': ['노트북', '마우스'], '가격': [1500000, 50000]})
df_prod_ship = pd.DataFrame({'무게(kg)': [1.5, 0.2], '배송비': [3000, 2500]})


# 1. 위아래 결합 (인덱스 초기화)
result_orders = pd.concat([df_seoul, df_suwon], axis=0, ignore_index=True)
print("--- [초급 1] 통합 주문 내역 ---")
print(result_orders)

# 2. 양옆 결합
result_catalog = pd.concat([df_prod_base, df_prod_ship], axis=1)
print("\n--- [초급 2] 종합 상품 카탈로그 ---")
print(result_catalog)





'''
### [중급 연습문제] K-클라우드 서버 월별 트래픽 결산 (컬럼 불일치 대응)

스타트업의 인프라 담당자가 되어 1월과 2월의 서버 사용량을 하나로 결산해야 합니다.
문제는 2월부터 정책이 바뀌어 '초과과금'이라는 새로운 항목이 데이터에 추가되었다는 점입니다.

**[문제 조건]**

1. 1월(`df_jan`)과 2월(`df_feb`) 데이터를 위아래(`axis=0`)로 결합하고 인덱스를 초기화하세요.
(항목이 다른 부분은 자동으로 NaN이 들어갑니다.)
2. 병합된 데이터에서 '초과과금' 열의 결측치(NaN)를 0으로 채우세요. (`fillna(0)` 활용)
3. 완성된 결산 데이터 양옆(`axis=1`)에 서버별 담당자 데이터(`df_admin`)를 연결하세요.
'''
# 1. 월별 서버 트래픽 데이터 (2월에는 '초과과금' 열이 추가됨)
df_jan = pd.DataFrame({'서버명': ['웹서버', 'DB서버'], '트래픽(TB)': [1.2, 3.5]})
df_feb = pd.DataFrame({'서버명': ['웹서버', 'DB서버'], '트래픽(TB)': [1.5, 3.8], '초과과금': [0, 50000]})

# 2. 담당자 데이터 (총 4줄의 데이터에 맞춰져 있음)
df_admin = pd.DataFrame({'담당자': ['김개발', '이엔지', '김개발', '이엔지']})

# 1. 위아래 결합 (1월에 없던 '초과과금' 열은 NaN으로 채워짐)
df_total_traffic = pd.concat([df_jan, df_feb], axis=0, ignore_index=True)

# 2. NaN 값을 0으로 채우기 (실무에서 매우 자주 쓰이는 전처리 기법)
df_total_traffic['초과과금'] = df_total_traffic['초과과금'].fillna(0)

# 3. 완성된 데이터 양옆에 담당자 데이터 결합
final_report = pd.concat([df_total_traffic, df_admin], axis=1)

print("--- [중급] 최종 서버 결산 리포트 ---")
print(final_report)


# [예제 2] Merge (관계형 병합) : 우주 대스타의 VIP 파티 출입 관리 실무
# 초대장 명단과 실제 도착 명단을 비교하여 출입을 통제합니다.
df_invite = pd.DataFrame({'이름': ['아이언맨', '배트맨', '슈퍼맨', '원더우먼'], '등급': ['VIP', 'Normal', 'VIP', 'Normal']})
df_arrive = pd.DataFrame({'이름': ['배트맨', '슈퍼맨', '스파이더맨'], '도착시간': ['20:00', '20:15', '20:30']})

# 1. [Inner] 진짜 인싸들만 남기기(초대장 O, 도착 O) - 이름을 지퍼의 이빨(on)로 삼습니다.
inner_party = pd.merge(df_invite, df_arrive, on="이름", how="inner" )
print("[Inner Merge] 파티장 입장 가능 인원\n", inner_party)
# 2. [Outer] 전체 명단  파악(초대받았거나 도착한 전체 인원 파악)
outer_party = pd.merge(df_invite, df_arrive, on="이름", how="outer")
print("[Outer Merge] 초대 및 방문자 전체 리스트\n", outer_party)
# 3. [Left] 초대장 명단 기준(누가 파티에 안 왔는지 불참자 확인)
left_party = pd.merge(df_invite, df_arrive, on="이름", how="left")
print("[Left Merge] 노쇼(No-Show) 인원 확인용\n", left_party)

# 4. [Right] 도착 명단 기준(초대장 없이 무단 침입한 사람 확인)
right_party = pd.merge(df_invite, df_arrive, on="이름", how="right")
print("[Right Merge] 초대장 없는 무단 방문자 확인용\n", right_party)
import pandas as pd

# ====================================================================================================
# [초급 문제] Merge (관계형 병합) : 우주 정거장 '스타게이트' 밀수품 단속 실무
# 합법적인 통관 허가 명단과 실제 화물선 도킹 명단을 비교하여 우주 해적과 밀수업자를 색출합니다.
# ====================================================================================================
# df_permit: 은하 연방에서 정식으로 화물 반입을 허가받은 우주선 명단
# df_docking: 실제 우주 정거장에 도킹하여 화물을 내리고 있는 우주선 명단
#
# 1. [Inner] 정상 통관 화물선: 허가증도 있고 도킹도 한 합법적인 우주선 명단을 확인하세요.
# 2. [Outer] 정거장 트래픽 총괄표: 통관 허가를 받았거나, 현재 도킹 중인 모든 우주선을 파악하세요.
# 3. [Left] 미도착 화물선(No-Show): 허가증은 발급받았으나 정거장에 도착한 인원과 정거장에 도착하지 않은 우주선을 구분하게 처리
# 4. [Right] 밀수선(무단침입): 허가증 없이 몰래 정거장에 도킹한 우주 해적을 색출하세요.
# ====================================================================================================

df_permit = pd.DataFrame({'우주선명': ['밀레니엄팔콘', '엔터프라이즈', '노스트로모', '가디언즈'], 
                          '화물종류': ['의료품', '연구장비', '광물', '식량']})
df_docking = pd.DataFrame({'우주선명': ['엔터프라이즈', '노스트로모', '블랙펄'], 
                           '도킹게이트': ['Gate_A', 'Gate_C', 'Gate_Z']})

inner_docking = pd.merge(df_permit, df_docking, on='우주선명', how='inner')
print("[초급 1. Inner Merge] 정상 통관 절차를 밟은 합법 우주선\n", inner_docking, "\n")

outer_docking = pd.merge(df_permit, df_docking, on='우주선명', how='outer')
print("[초급 2. Outer Merge] 은하 연방 관리 대상 전체 트래픽 현황\n", outer_docking, "\n")

left_docking = pd.merge(df_permit, df_docking, on='우주선명', how='left')
print("[초급 3. Left Merge] 허가는 받았으나 아직 도착하지 않은 우주선\n", left_docking, "\n")

right_docking = pd.merge(df_permit, df_docking, on='우주선명', how='right')
print("[초급 4. Right Merge] 허가증 없이 무단으로 도킹한 불법 밀수선\n", right_docking, "\n")



# ====================================================================================================
# [중급 문제] Merge 및 데이터 정제 : 극비 첩보 기관(MI6) 요원 작전 배치 실무
# 소속된 요원 명단과 현재 진행 중인 극비 작전 목록을 병합하여 인력 낭비와 구멍난 작전을 막아야 합니다.
# ====================================================================================================
# df_agents: 현재 소속된 전체 요원 명단 (요원코드, 요원명, 주특기)
# df_missions: 현재 진행 중인 작전과 배정된 요원코드 (요원코드, 작전명, 위험도)
#
# 1. [Left + 조건검색] 요원 명단을 기준으로 병합한 뒤, 현재 작전에 배정되지 않고 
#    본부에서 대기만 하고 있는 '잉여 요원'들만 필터링하여 출력하세요.
# 2. [Outer + 결측치(NaN) 처리] 모든 요원과 작전 현황을 병합한 전체 현황판을 만듭니다.
#    - 작전명이 없는 요원의 작전명 결측치는 '대기중'으로 채우고,
#    - 요원명이 없는 작전의 요원명 결측치는 '긴급배정요망'으로 채워 완벽한 데이터프레임을 만드세요.
# ====================================================================================================

df_agents = pd.DataFrame({'요원코드': ['001', '007', '008', '009'],
                          '요원명': ['제임스', '본드', '이단', '블랙위도우'],
                          '주특기': ['저격', '잠입', '해킹', '격투']})
df_missions = pd.DataFrame({'요원코드': ['007', '009', '999'],
                            '작전명': ['카지노 로얄', '레드룸 폭파', '언더커버'],
                            '위험도': ['최상', '상', '중']})
left_agents = pd.merge(df_agents, df_missions, on='요원코드', how='left')
lazy_agents = left_agents[left_agents['작전명'].isnull()]
print("[중급 1. Left + Filter] 현재 임무가 없어 본부에서 대기 중인 잉여 요원 명단\n", lazy_agents, "\n")

outer_agents = pd.merge(df_agents, df_missions, on='요원코드', how='outer')
outer_agents['작전명'] = outer_agents['작전명'].fillna('대기중')
outer_agents['요원명'] = outer_agents['요원명'].fillna('긴급배정요망')
outer_agents['주특기'] = outer_agents['주특기'].fillna('미확인(외부용병)')
outer_agents['위험도'] = outer_agents['위험도'].fillna('위험없음')
print("[중급 2. Outer + Fillna] 결측치를 완벽하게 처리한 MI6 전체 작전 현황판\n", outer_agents)
                            

