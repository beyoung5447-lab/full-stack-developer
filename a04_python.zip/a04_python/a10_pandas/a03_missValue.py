import pandas as pd
import numpy as np

# 1. 구멍(NaN)이 뚫려 있는 예제 데이터 생성
data_salad = {
    '주문번호': [1, 2, 3, 4, 5],
    '메뉴': ['닭가슴살', '연어', np.nan, '스테이크', '연어'],
    '칼로리': [450, 520, np.nan, 600, 520],
    '배달시간(분)': [20, 35, 25, np.nan, 30]
}
df_salad = pd.DataFrame(data_salad)
print(df_salad)
# 대체 처리(Fill) : 합리적인 값으로 구멍을 메워 데이터를 복원합니다.
# 1. 메뉴 : 가장 많이 팔리는 연어로 채우기
df_salad['메뉴'] = df_salad['메뉴'].fillna("연어")
print("연어로 채운 후:\n", df_salad)
# 2. 칼로리 : 전체 메뉴 칼로리의 평균값으로 채우기
mean_cal = df_salad['칼로리'].mean()
df_salad['칼로리'] = df_salad['칼로리'].fillna(mean_cal)
print("칼로리 평균값 채운 후:\n", df_salad)
# 3. 배달시간 : 흐름상 바로 앞 주문의 배달시간(ffill)으로 복사해서 채우기
df_salad['배달시간(분)'] = df_salad['배달시간(분)'].ffill()
print("앞 주문 배달시간으로 채운 후:\n", df_salad) 



import pandas as pd
import numpy as np

data_gym = {
    '회원번호': [101, 102, 103, 104, 105],
    '운동종목': ['웨이트', '런닝머신', np.nan, '요가', '런닝머신'],
    '소모칼로리': [400, 350, np.nan, 200, 350],
    '운동시간(분)': [50, 40, 60, np.nan, 45]
}
df_gym = pd.DataFrame(data_gym)
print("전체 회원 운동 기록:\n", df_gym, "\n")

'''
## 🟢 초급 문제 

제공된 `df_gym` 데이터에 뚫린 구멍(NaN)을 배운 기법들을 활용하여 합리적으로 메워보세요.

1. **[특정 값 채우기]** 누락된 '운동종목'을 헬스장에서 가장 인기 있는 "런닝머신"으로 채우고 결과를 출력하세요.
2. **[평균값 채우기]** 누락된 '소모칼로리'를 전체 회원들의 소모칼로리 '평균(mean)' 값으로 채우고 출력하세요.
3. **[이전 값 채우기]** 누락된 '운동시간(분)'은 바로 앞 회원의 운동 시간을 따라 했다고 가정하고 `ffill`로 채우세요.
'''
print(df_gym)
df_gym['운동종목'] = df_gym['운동종목'].fillna("런닝머신")
print(df_gym)
mean_cal = df_gym['소모칼로리'].mean()
df_gym['소모칼로리'] = df_gym['소모칼로리'].fillna(mean_cal)
print(df_gym)
df_gym['운동시간(분)'] = df_gym['운동시간(분)'].ffill()
print(df_gym)

'''
## 🔵 중급 문제 

실무에서는 평균이 아닌 중앙값을 쓰거나, 한 번에 여러 컬럼의 결측치를 각기 다른 값으로 채워야 할 때도 있습니다.

1. **[중앙값 채우기]** 특정 회원의 수치가 비정상적으로 높으면 평균이 왜곡됩니다. (데이터 원본 재사용 가정)
'소모칼로리'의 결측치를 평균 대신 안전한 '중앙값(median)'을 계산하여 채워보세요.
2. **[이후 값 채우기]** '운동시간(분)'을 앞 사람이 아닌, 바로 '뒤'에 있는 사람의 시간으로 채우려고 합니다.
`ffill` 대신 바로 뒤의 값으로 채우는 `bfill` (backward fill) 메서드를 사용하여 복원해 보세요.
3. **[딕셔너리 동시 처리]** `fillna({'A': 10, 'B': 20})` 형태의 딕셔너리를 활용해 보세요.
'운동종목'은 '스트레칭', '소모칼로리'는 300, '운동시간(분)'은 30으로 세 컬럼을 한 번에 채워보세요.

'''

# 원본 데이터가 유지되어 있다고 가정하고 새로운 변수에 데이터프레임을 다시 생성합니다.
df_gym_mid = pd.DataFrame(data_gym)

# 1. 극단적인 값에 영향을 덜 받는 중앙값(median)으로 안전하게 채우기
median_cal = df_gym_mid['소모칼로리'].median()
df_gym_mid['소모칼로리'] = df_gym_mid['소모칼로리'].fillna(median_cal)

# 2. 바로 뒤의 데이터(bfill)를 복사해서 위로 채우기
df_gym_mid['운동시간(분)'] = df_gym_mid['운동시간(분)'].bfill()
print("1~2. 중앙값과 bfill 적용 후:\n", df_gym_mid, "\n")

# 3. 딕셔너리를 활용하여 여러 컬럼의 결측치를 한 번의 코드로 일괄 처리하기
df_gym_multi = pd.DataFrame(data_gym) # 데이터 다시 초기화
fill_dict = {'운동종목': '스트레칭', '소모칼로리': 300, '운동시간(분)': 30}
df_gym_multi = df_gym_multi.fillna(fill_dict)
print("3. 딕셔너리로 한 번에 다중 결측치 채우기:\n", df_gym_multi)