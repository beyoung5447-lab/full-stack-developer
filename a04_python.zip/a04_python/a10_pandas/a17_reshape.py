'''
[데이터 분석 실전 교안: 데이터 재구조화 완벽 마스터]

1. 오프닝 및 개요 (Overview)
데이터 분석 실무를 하다 보면, 원본 데이터의 형태가 분석이나 보고서 작성에 맞지 않는 경우가 아주 많습니다.
경영진 보고를 위해 요약표처럼 한눈에 들어오게 넓게 펼쳐야(Wide Format) 할 때가 있고,
데이터 시각화나 머신러닝 모델 학습을 위해 세로로 촘촘하고 길게 늘어뜨려야(Long Format) 할 때도 있습니다.
이렇게 데이터의 구조를 자유자재로 바꾸는 '재구조화(Reshaping)'의 두 가지 핵심 무기,
pivot_table()과 melt()를 완벽하게 내 것으로 만들어 보겠습니다.
2. 전문용어 개념 및 최적의 암기법 (Concepts & Mnemonics)

[핵심 무기 1] pivot_table() : 넓고 보기 좋게 요약하기 (Cross-tabulation)

* 전문 개념: 길게 나열된 원시 데이터를 지정한 행과 열을 기준으로 재배치하여, 통계값(합계, 평균 등)을
한눈에 볼 수 있는 2차원 교차표 형태로 변환합니다. 엑셀의 피벗 테이블과 완벽하게 동일한 기능입니다.
* 주요 매개변수:
* index : 고정할 행 기준 (세로축)
* columns : 가로로 펼칠 열 기준 (가로축)
* values : 표 안에 채워 넣어 계산할 대상 데이터
* aggfunc : 적용할 통계 함수 (기본값은 mean이며, sum, max 등 사용 가능)


* 최고 효율 암기법: "농구의 피벗(Pivot) 스텝"
농구 경기에서 한 발은 코트 바닥에 꽉 고정(index)하고, 다른 발은 넓게 펼쳐(columns) 수비를 살핀 뒤,
정확하게 공(values)을 모아서 원하는 방식(aggfunc)으로 던져 득점하는 역동적인 모습을 상상해 보세요.

[핵심 무기 2] melt() : 넓은 데이터를 길게 녹여 내리기 (Unpivoting)

* 전문 개념: 가로로 넓게 퍼져 있는 데이터를 컴퓨터가 분석하거나 그래프로 그리기 좋은 '변수-값' 구조의
세로로 긴 형태(Long format)로 변환합니다.
* 주요 매개변수:
* id_vars : 녹이지 않고 그대로 유지할 기준 열 (막대기)
* value_vars : 아래로 길게 녹일 대상 열들
* var_name : 녹아내린 원래 열 이름들이 들어갈 새로운 열의 이름
* value_name : 녹아내린 실제 데이터 값들이 들어갈 새로운 열의 이름


* 최고 효율 암기법: "아이스크림 멜트(Melt, 녹이다)"
아이스크림을 먹을 때, 튼튼한 손잡이 막대기(id_vars)는 손으로 꽉 잡고 남겨둔 채, 가로로 넓게 얹혀 있던
아이스크림 덩어리들(value_vars)이 열기에 의해 아래로 주르르 길게(Long) 녹아내려,
새로운 맛표(var_name)와 내용물(value_name)이 되어 컵에 담기는 모습을 떠올려 보세요.

'''
import pandas as pd
import numpy as np

df_hr = pd.DataFrame({
'Dept': ['개발팀', '개발팀', '기획팀', '기획팀', '개발팀', '기획팀'],
'Year': ['2022', '2023', '2022', '2023', '2022', '2023'],
'Salary': [6000, 6500, 4500, 4800, 6200, 4900]
})
print(df_hr)
'''
# pivot_table() : 글로벌 IT 기업 부서별, 연도별 평균 연봉 요약 보고서
보고를 위해 세로로 긴 인사 데이터를 부서와 연도 기준으로 한눈에 보이게 요약 합니다.
'''
# 농구 스텝 : 한 발(Dept)는 세로로 고정, 다른 발(Year)은 넓게 펼치고 연봉(Salary)의 평균(mean) 구하기
result_pivot =  df_hr.pivot_table(index="Dept", columns='Year', values="Salary", aggfunc="mean")
print("부서/연도별 평균 연봉 보고서\n", result_pivot)

'''
[초급 연습문제] 데이터 재구조화의 기본기 다지기
문제 1 (pivot_table):
온라인 쇼핑몰의 데이터입니다. 회원등급(Grade)을 행(index)으로, 구매 카테고리(Category)를 열(columns)로
배치하여 카테고리별 구매액(Amount)의 총합(sum)을 보여주는 피벗 테이블을 작성하세요.
'''

df_shop = pd.DataFrame({
'Grade': ['VIP', 'Gold', 'VIP', 'Gold', 'VIP'],
'Category': ['Electronics', 'Fashion', 'Fashion', 'Electronics', 'Electronics'],
'Amount': [150, 80, 200, 50, 300]
})
print(df_shop)
# Grade : 행(index), Category : 열 컬럼,  데이터 - Amount, 통계함수 총합(sum)
ans_pivot = df_shop.pivot_table(index="Grade", columns="Category", values="Amount", aggfunc="sum")
print("피봇테이블 \n", ans_pivot)



'''
[중급 연습문제] 실무형 복합 데이터 정제 프로젝트
마케팅 부서에서 분기별 광고 매체 성과 데이터를 엑셀로 전달받았습니다.
데이터가 너무 넓게 퍼져 있어서 월별 트렌드 분석이 불가능합니다.
데이터를 길게 녹인 다음(melt), 다시 원하는 형태로 요약(pivot_table)하는 복합 파이프라인을 구축하세요.

조건 1 (Melt): Campaign과 Platform을 모두 막대기(id_vars)로 2개 고정하고, Q1_Clicks와 Q2_Clicks를 녹이세요.
새롭게 생성되는 열 이름은 분기를 뜻하는 'Quarter', 값 열 이름은 'Clicks'로 설정하세요.
조건 2 (Pivot): 위에서 길게 녹인 데이터를 바탕으로 다시 피벗 테이블을 만드세요.
행(index)에는 'Quarter'를, 열(columns)에는 'Platform'을 배치하고,
클릭 수(Clicks)의 합계(sum)를 구하는 2차원 교차표를 완성하세요.
'''


df_marketing = pd.DataFrame({
'Campaign': ['신년이벤트', '여름바캉스'],
'Platform': ['Instagram', 'YouTube'],
'Q1_Clicks': [1200, 3500],
'Q2_Clicks': [1500, 4200]
})

# 조건 1: 두 개의 열을 기준으로 잡고 데이터를 길게 녹이기

melted_mkt = df_marketing.melt(id_vars=['Campaign', 'Platform'],
value_vars=['Q1_Clicks', 'Q2_Clicks'],
var_name='Quarter', value_name='Clicks')
print("1단계 변환 완료:\n", melted_mkt)



df_sales = pd.DataFrame({
'Branch': ['강남점', '부산점'],
'Fri_Sales': [250, 180],
'Sat_Sales': [400, 320],
'Sun_Sales': [350, 300]
})
print(df_sales)
# melt() - 프랜차이즈 식당의 요일별 매출 데이터 시각화용으로 변환하기
# 가로로 넓게 퍼진 요일별 매출 데이터를, 시각화 도구(그래프)에 넣기 좋게 세로로 길게 녹입니다.
# 막대를(Branch)를 꽉 잡고, 주말 매출 덩어리(Fri, Sat, Sun)를 아래로 길게 녹여 내리기
result_melt = df_sales.melt(
    id_vars="Branch",
    value_vars=["Fri_Sales","Sat_Sales","Sun_Sales"],
    var_name="Day_Type",
    value_name="Revenue"
)
print("시각화용 긴 형태의 매출 데이터\n", result_melt)

'''
헬스장 회원들의 체중 기록입니다. 이름(Name)을 유지할 기준(id_vars)으로 꽉 잡고,
Jan_Weight와 Feb_Weight 열을 길게 녹여서, 새로운 열 이름을 각각 'Month', 'Weight'로 지정하는 코드를 작성하세요.
'''
df_weight = pd.DataFrame({
'Name': ['김철수', '이영희'],
'Jan_Weight': [75, 60],
'Feb_Weight': [73, 59]
})
print(df_weight)
'''
  Name     Jan_Weight   Feb_Weight
0  김철수          75          73
1  이영희          60          59

Jan_Weight   Feb_Weight 부분을 데이터 늘려서 처리하기 위한 내용..

이름    월구분몸무게  몸무게
김철수  Jan_Weight   75
김철수  Feb_Weight   73
이영희  Jan_Weight   60
이영희  Feb_Weight   59
'''
ans_melt = df_weight.melt(id_vars="Name", value_vars=["Jan_Weight","Feb_Weight"], 
                          var_name="Month", value_name="Weight"  )
print(ans_melt)



'''
## [중급 문제] 신약 임상시험 환자별 혈압 변화 추적 데이터 변환

신약을 투약한 환자들의 투약 전/후 혈압 변화 데이터입니다.
단일 기준이 아니라 다수의 막대기(id_vars)를 고정하고 쓸모없는 열을 배제해야 합니다.
다음 실무 조건들을 모두 만족하는 긴 형태의 데이터를 만드세요.

* 조건 1: 환자ID(`Patient_ID`)와 성별(`Gender`) 2개를 막대기로 단단히 고정하세요.
* 조건 2: 나이(`Age`) 열은 분석 대상이 아니므로 깔끔하게 제외하세요.
* 조건 3: 변환된 결과 데이터를 환자ID 기준으로 정렬(`sort_values`)하여 비교하기 쉽게 만드세요.
'''

# 데이터 생성: 임상시험 전/후 혈압 데이터
df_clinic = pd.DataFrame({
    'Patient_ID': ['P001', 'P002', 'P003'],
    'Gender': ['M', 'F', 'M'],
    'Age': [45, 52, 38], # 이 데이터는 녹일 때 무시해야 합니다.
    'Before_BP': [145, 150, 138],
    'After_BP': [120, 125, 115]
})

# id_vars에 리스트로 두 개의 컬럼을 전달하여 기준을 2개로 잡습니다.
# value_vars에 명시되지 않은 Age 컬럼은 결과에서 자동으로 날아갑니다.
res_clinic = df_clinic.melt(
    id_vars=['Patient_ID', 'Gender'],
    value_vars=['Before_BP', 'After_BP'],
    var_name='Test_Stage',
    value_name='Blood_Pressure'
).sort_values(by='Patient_ID')

print("\n환자별 혈압 변화 추적 데이터(정렬 완료):\n", res_clinic)
