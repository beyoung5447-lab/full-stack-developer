'''
# 범위 간격
1. np.arange(start, end, step) : 발자국 세기
   여기서부터 저기까지 2보폭씩 걸어가세요..
'''
# arange이용해서 10부터 30미만, 5간격
import numpy as np
step_arr = np.arange(10,30, 5)
print("10부터 30미만 5간격:", step_arr)
# 5부터 100까지 5단위로 배열 리스트 만드세요
list01 = np.arange(5, 100+1, 5)
print('5부터 100까지 5단위',list01)
'''
# np.linespace(start, stop, num) : 깃발 꽂기
1. 여기서부터 저기까지 정확히 5개로 깃발 꽂기으로 나눠
2. 갯수(num)을 지정합니다. stop 숫자가 포함됩니다.

'''
# liespace를 이용해서 0 부터 10까지 정확히 5개 깃발 꽂기 하기
print("0부터 10까지 정확히 5개 꽂기 하기:", np.linspace(0, 10, 5))
# 0부터 100까지 분할
print("0부터 100까지 분할 ", np.linspace(0, 100, 5))

'''
# Numpy에서 난수(임의의 수)처리
1. 임의의 수는 머신러닝, 통계 시뮬레이션 등 여러 분야에 다양한 확율 분포에 따라 무작위
표본을 생성할 때, 활용하는 기능 메서드 입니다.
2. 컴퓨터가 생성하는 난수는 완전히 무작위가 아닌, 정해진 시작점(seed)에서 예측 가능한
순서로 생성하는 의사 난수입니다.
3. Numpy의 난수 생성은 크게 두가지 방식으로 접근할 수 있습니다.
   1) 레거시 방식(np.random.*) : np.random.rand(), np.random.randint()처럼 모듈 수준에서
   직접 함수를 호출학는 간편한 방식입니다.
   2) 현대적 방식(np.random.Generator) : np.random.default_rng()를 통해서 생성기(Generator)
   객체를 먼저 만들고, 그 객체의 메서드를 호출하는 방식입니다. 이 방식은 
   재현성 및 여러 활률 분포 지원 측면에 더 우수하여 현재 권장되는 방법입니다.
4. 주요 기능 및 메서드
    - 난수 생성기 초기화(권장 방식)
    항상 동일한 순서의 난수를 얻고 싶다면 시드(seed)를 설정해야 합니다. 이는 코드의 재현성을
    보장하는 중요한 단계입니다. 현재적 방식에는 default_rng()메서드 값을 전달하여 생성하는
    객체를 만듭니다.
    ex) 
    # 시드값을 이용해 난수 생성기(Generator) 객체 생성
    rng = np.random.default_rng(seed = 42)
    - 생성한 객체를 통해 난수 배열 생성
    random_floats = rng.random(size=(2,3))
    - 재현 가능한 무작위 실수 배열
    # 시드 없이 생성하면 실행할 때마다 다른 결과값이 나옵니다.
    rng_new = np.random.default_rng()
'''
import numpy as np
# 시드를 통한 랜덤값 처리
rng = np.random.default_rng(seed = 42)
print("시드 설정후 객체:", rng)
random_floats = rng.random(size=(2,3))
print("실행시 마다 동일한 임의의 실수 행렬(2,3)\n",random_floats)
# 1~6까지 주사위, 크기는 10개, 한번 실행되면 실행될 때만다. 동일 데이터 처리..
random_integers = rng.integers(low=1, high=6+1, size=10)
print("# seed 형 정수 랜덤 #")
print(random_integers)
# 시드 없이 랜덤값 처리..
rng_new = np.random.default_rng()
print("시드 없는 객체:", rng_new)
print("시드 없는 2행 3열 임의 값:", rng_new.random(size=(2,3)))
# 1~6가지 주사위 크기는 25개, 계속 실행시 마다 임의의 값 출력.
print("시드 없는 주사위:", rng_new.integers(low=1, high=6+1, size=25)) 
'''
# np.choice(배열, size=임의가져올크기, replace=False)   replace : 중복여부를 설정..
# np.shuffle(배열) : 특정한 배열을 무작위로 섞는 처리..
'''






