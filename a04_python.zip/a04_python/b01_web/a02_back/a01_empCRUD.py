from fastapi import FastAPI, Query, HTTPException
from fastapi.responses import FileResponse
from pydantic import BaseModel
from typing import Optional
import oracledb
import os
# pip install oracledb
app = FastAPI()

DB_USER = "scott"
DB_PASSWORD = "tiger"
DB_DSN = "localhost:1521/FREE" 
# a01_exp/b01_web
# cd a04_python
# cd b01_web

# uvicorn a02_back.a01_empCRUD:app --reload

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
FRONT_DIR = os.path.join(os.path.dirname(BASE_DIR), 'a01_front')
HTML_PATH = os.path.join(FRONT_DIR, 'a01_empCRUD.html')

# 데이터 검증을 위한 Pydantic 모델
class Employee(BaseModel):
    empno: int
    ename: str
    job: str
    mgr: Optional[int] = None
    hiredate: str
    sal: float
    comm: Optional[float] = None
    deptno: int

def get_db_connection():
    return oracledb.connect(user=DB_USER, password=DB_PASSWORD, dsn=DB_DSN)

@app.get("/", response_class=FileResponse)
async def read_root():
    return FileResponse(HTML_PATH)

# 검색 및 목록 조회 (사원명, 직책 키워드 검색 추가)
@app.get("/api/emp")
async def get_employees(ename: str = "", job: str = ""):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        
        query = """
            SELECT empno, ename, job, mgr, 
                   TO_CHAR(hiredate, 'YYYY-MM-DD') as hiredate, 
                   sal, comm, deptno 
            FROM emp01
            WHERE ename LIKE '%' || :ename || '%' 
              AND job LIKE '%' || :job || '%'
            ORDER BY empno
        """
        cursor.execute(query, ename=ename.upper(), job=job.upper())
        columns = [col[0].lower() for col in cursor.description]
        employees = [dict(zip(columns, row)) for row in cursor.fetchall()]
        
        cursor.close()
        conn.close()
        return employees 
    except Exception as e:
        return {"error": str(e)}

# 단일 사원 상세 조회
@app.get("/api/emp/{empno}")
async def get_employee(empno: int):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        query = """
            SELECT empno, ename, job, mgr, 
                   TO_CHAR(hiredate, 'YYYY-MM-DD') as hiredate, 
                   sal, comm, deptno 
            FROM emp01 WHERE empno = :empno
        """
        cursor.execute(query, empno=empno)
        row = cursor.fetchone()
        if not row:
            raise HTTPException(status_code=404, detail="Employee not found")
            
        columns = [col[0].lower() for col in cursor.description]
        employee = dict(zip(columns, row))
        cursor.close()
        conn.close()
        return employee
    except Exception as e:
        return {"error": str(e)}

# 사원 등록
@app.post("/api/emp")
async def create_employee(emp: Employee):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        query = """
            INSERT INTO emp01 (empno, ename, job, mgr, hiredate, sal, comm, deptno) 
            VALUES (:1, :2, :3, :4, TO_DATE(:5, 'YYYY-MM-DD'), :6, :7, :8)
        """
        cursor.execute(query, (emp.empno, emp.ename.upper(), emp.job.upper(), emp.mgr, emp.hiredate, emp.sal, emp.comm, emp.deptno))
        conn.commit()
        cursor.close()
        conn.close()
        return {"message": "등록 성공"}
    except Exception as e:
        return {"error": str(e)}

# 사원 수정
@app.put("/api/emp/{empno}")
async def update_employee(empno: int, emp: Employee):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        query = """
            UPDATE emp01 
            SET ename=:1, job=:2, mgr=:3, hiredate=TO_DATE(:4, 'YYYY-MM-DD'), 
                sal=:5, comm=:6, deptno=:7 
            WHERE empno=:8
        """
        cursor.execute(query, (emp.ename.upper(), emp.job.upper(), emp.mgr, emp.hiredate, emp.sal, emp.comm, emp.deptno, empno))
        conn.commit()
        cursor.close()
        conn.close()
        return {"message": "수정 성공"}
    except Exception as e:
        return {"error": str(e)}

# 사원 삭제
@app.delete("/api/emp/{empno}")
async def delete_employee(empno: int):
    try:
        conn = get_db_connection()
        cursor = conn.cursor()
        query = "DELETE FROM emp01 WHERE empno = :empno"
        cursor.execute(query, empno=empno)
        conn.commit()
        cursor.close()
        conn.close()
        return {"message": "삭제 성공"}
    except Exception as e:
        return {"error": str(e)}