# SELECT * FROM STUDENT
from  a00_con import dbCon as con
try:
   conn = con() # 연결객체
   cursor = conn.cursor()
   sql = '''
    SELECT * FROM STUDENT
   '''
   cursor.execute(sql)
   students = cursor.fetchall()
   print("# 학생 정보 #\n", students)
   
   
except Exception as e:
   print("예외 발생:", e)
finally:
   # 예외 상관없이
   if cursor:  # 아직 해당 객체가 메모리를 사용하고 있다면
      cursor.close() # 해제해준다.
   if conn:
      conn.close()
   print("예외 처리 및 프로그램 자원 해제 후, 완료!!")  