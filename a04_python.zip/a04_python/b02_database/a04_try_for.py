'''
# 예외 처리 구문 
1. 프로그램밍에서 예외는 특정한 코드 실행시 에러사항이나 문제가 발생했을 때, 
처리하는 프로그램의 안정성을 위한 코드 입니다.
2. 기본 형식
    try:
       처리할 코드
    except Exception as e:  # Exception은 대표적인 예외 처리 내장객체입니다.
       처리할 코드에서 에러 발생시 수행할 내용
       print("예외발생:",e) # 예외 정보를 
    finally:
       # 예외 상관없이 무조건 실행할 코드
       if cursor:
          cursor.close()  # DB의 경우 cursor(실행처리객체) 자원해제 처리합니다.
       if con:
          con.close() # DB의 경우 con(연결) 자원해제 처리   



# 반복문 처리
1. 결과데이터에 대한 처리 방식
   - 기본 결과 유형 : 튜플(고정형 배열)
   - 다중 행 : 리스트(튜플1, 튜플2,....)
   ex)  [(1, '홍길동', 80, 90, 80), (2, '길길동', 70, 95, 82), (3, '신길동', 90, 93, 75)]
2. 리스트형(튜플 데이터) 반복문 처리1
   for dup in fetcall결과:
       dup  (1, '홍길동', 80, 90, 80)
       dup[0]
       dup[1]
       dup[2]
       dup[3]
       dup[4]

3. Dto로 연동 하여 효율적 처리

'''
# 부서 정보 조회시 예외 처리
from  a00_con import dbCon as con
try:
   conn = con() # 연결객체
   cursor = conn.cursor()
   sql = '''
    SELECT * FROM DEPT
   '''
   cursor.execute(sql)
   deptList = cursor.fetchall()
   print("부서정보 조회 결과:\n",deptList)
   for deptTup in deptList:
      print(deptTup[0], end="\t") # 부서번호
      print(deptTup[1].ljust(10), end="\t") # 부서명 .ljust(10) : 문자열의 최소크기설정(왼쪽)
      print(deptTup[2]) # 부서위치


except Exception as e:
   print("예외 발생:", e)
finally:
   # 예외 상관없이
   if cursor:  # 아직 해당 객체가 메모리를 사용하고 있다면
      cursor.close() # 해제해준다.
   if conn:
      conn.close()
   print("예외 처리 및 프로그램 자원 해제 후, 완료!!")   

'''
-- 실무 실습용 테이블 및 데이터 생성
CREATE TABLE TBL_TECH_PROJECT (
    PROJ_ID NUMBER(4) PRIMARY KEY,
    PROJ_NAME VARCHAR2(100),
    MANAGER VARCHAR2(50),
    BUDGET NUMBER(10)
);

INSERT INTO TBL_TECH_PROJECT VALUES (2001, 'AI 챗봇 개발', '김수석', 50000);
INSERT INTO TBL_TECH_PROJECT VALUES (2002, '사내 클라우드 이전', '박책임', 85000);
INSERT INTO TBL_TECH_PROJECT VALUES (2003, '보안 시스템 고도화', '이선임', 32000);
INSERT INTO TBL_TECH_PROJECT VALUES (2004, '사내 복지몰 리뉴얼', '최주임', 15000);

COMMIT;

'''

'''


[초급 연습문제: 기본 예외 처리 및 전체 데이터 반복 출력]

사내 전체 IT 프로젝트 목록을 조회하여 화면에 출력하는 프로그램을 작성하세요.
DB 연결부터 쿼리 실행, 반복문을 통한 결과 출력까지 진행하며,
반드시 try-except-finally 구문을 사용하여 예외 발생 시 안전하게 자원을 해제해야 합니다.

* 요구사항:

1. a00_con 모듈의 dbCon을 사용하여 커넥션을 생성하세요.
2. TBL_TECH_PROJECT 테이블의 모든 데이터를 조회하세요.
3. for문을 사용하여 "프로젝트번호: OOO, 프로젝트명: OOO, 담당자: OOO" 형태로 출력하세요.
4. 에러 발생 시 "예외 발생: 에러내용"을 출력하고, finally에서 자원을 닫으세요.


'''          
