# DB 연동 공통 모듈 설정
import oracledb
def dbCon():
    DB_USER="scott"
    DB_PASSWORD="tiger"
    DB_DSN="localhost:1521/FREE"
    con = oracledb.connect(user=DB_USER, password=DB_PASSWORD, dsn=DB_DSN)
    print("연결확인:", "성공" if con else "실패")
    return con
# 조회시 기본 코드
'''
from  a00_con import dbCon as con
from dataclasses import dataclass
@dataclass
class XXXDTO:
    no : int
try:
   conn = con() # 연결객체
   cursor = conn.cursor()
   sql='''  '''
   cursor.execute(sql)
   result_rows = cursor.fetchall()
   dto_list = [XXXDTO(*row) for row in result_rows]
   for ob in dto_list:
      print(ob.no,end="\t")
      print()

   
except Exception as e:
   print("예외 발생:", e)
finally:
   # 예외 상관없이
   if cursor:  # 아직 해당 객체가 메모리를 사용하고 있다면
      cursor.close() # 해제해준다.
   if conn:
      conn.close()
   print("예외 처리 및 프로그램 자원 해제 후, 완료!!")   
'''

# 등록, 수정, 삭제시 기본 코드
'''
from  a00_con import dbCon as con
from dataclasses import dataclass
@dataclass
class XXXDTO:
   no : int

   
try:
   conn = con() # 연결객체
   cursor = conn.cursor()
   sql = ''' '''
   dto = XXXDTO()

   cursor.execute(sql, dto.__dict__)


   conn.commit()   
   print("성공")
except Exception as e:
   print("예외 발생:", e)
   if conn:
      conn.rollback() # 에러 발생 시 원복 처리   
finally:
   # 예외 상관없이
   if cursor:  # 아직 해당 객체가 메모리를 사용하고 있다면
      cursor.close() # 해제해준다.
   if conn:
      conn.close()
   print("예외 처리 및 프로그램 자원 해제 후, 완료!!") 

'''