'''
[초급 연습문제: 기본 예외 처리 및 전체 데이터 반복 출력]

사내 전체 IT 프로젝트 목록을 조회하여 화면에 출력하는 프로그램을 작성하세요.
DB 연결부터 쿼리 실행, 반복문을 통한 결과 출력까지 진행하며,
반드시 try-except-finally 구문을 사용하여 예외 발생 시 안전하게 자원을 해제해야 합니다.

* 요구사항:

1. a00_con 모듈의 dbCon을 사용하여 커넥션을 생성하세요.
2. TBL_TECH_PROJECT 테이블의 모든 데이터를 조회하세요.
3. 에러 발생 시 "예외 발생: 에러내용"을 출력하고, finally에서 자원을 닫으세요.

'''
from a00_con import dbCon as con
try:
    conn = con()
    cursor = conn.cursor()
    sql = '''
         SELECT * FROM TBL_TECH_PROJECT
    '''
    cursor.execute(sql)
    prjList = cursor.fetchall()
    print("프로젝트 리스트\n", prjList)



except Exception as e:
    print("예외 발생: 에러 내용:", e)
finally :
    if cursor:
        cursor.close()
    if conn:
        conn.close()




'''
[중급 연습문제: 조건 검색 융합 및 고의적 예외 유도 처리]

특정 예산(BUDGET) 이상의 대형 프로젝트만 검색하는 프로그램을 작성하세요.
실무에서는 쿼리 작성 실수나 DB 서버 문제로 돌발 에러가 잦습니다.
이번 문제에서는 쿼리문에 의도적인 오타를 넣어 예외 처리 블록이 정상 작동하는지 확인합니다.

* 요구사항:

1. 사용자로부터 검색할 '최소 예산'을 정수로 입력받으세요.
2. 바인딩 변수(:budget)를 활용하여 예산 이상인 프로젝트를 조회하도록 SQL을 작성하되,
테이블명을 고의로 'TBL_TECH_PROJECT_ERROR'로 잘못 입력하여 에러를 유도하세요.
3. Exception 블록이 실행되면 시스템 에러 내용 출력 후,
사용자에게는 "현재 DB 서버 점검 중입니다"라는 안내 메시지를 추가로 띄우세요.
4. 예외 발생 시 프로그램이 멈추지 않고 finally 블록에서 자원이 해제되어야 합니다.
'''