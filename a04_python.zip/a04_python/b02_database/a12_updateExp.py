'''
CREATE TABLE HERO_MART (
    ITEM_ID NUMBER PRIMARY KEY,
    ITEM_NAME VARCHAR2(100),
    CATEGORY VARCHAR2(50),
    PRICE NUMBER,
    STOCK NUMBER,
    POWER_LEVEL NUMBER(3,1),
    STATUS VARCHAR2(20)
);

-- 초기 데이터 입력
INSERT INTO HERO_MART VALUES (1, '투명해지는 생수', '음식', 1500, 20, 5.5, '판매중');
INSERT INTO HERO_MART VALUES (2, '순간이동 망토', '의류', 50000, 5, 9.9, '판매중');
INSERT INTO HERO_MART VALUES (3, '화염 저항 장갑', '방어구', 25000, 10, 7.5, '준비중');
COMMIT;
UPDATE HERO_MART
   SET ITEM_NAME = '향기나는 망토',
       CATEGORY = '의류',
       PRICE = 7000,
       STOCK = 7,
       POWER_LEVEL = 7.7,
       STATUS = '준비중'
  WHERE ITEM_ID = 2; 
COMMIT;   
SELECT * FROM HERO_MART;   

'''
from  a00_con import dbCon as con
from dataclasses import dataclass
@dataclass
class HeroMartDTO:
    item_id:int
    item_name:str
    category:str
    price:int
    stock:int
    power_level:float
    status:str

   
try:
   conn = con() # 연결객체
   cursor = conn.cursor()
   sql = ''' 
        UPDATE HERO_MART
        SET ITEM_NAME = :item_name,
            CATEGORY = :category,
            PRICE = :price,
            STOCK = :stock,
            POWER_LEVEL = :power_level,
            STATUS = :status
        WHERE ITEM_ID = :item_id'''
   dto = HeroMartDTO(3, '냉기 저항 투구','방어구',30000,12,8.0,'판매중')

   cursor.execute(sql, dto.__dict__)


   conn.commit()   
   print("성공")
except Exception as e:
   print("예외 발생:", e)
   if conn:
      conn.rollback() # 에러 발생 시 원복 처리   
finally:
   # 예외 상관없이
   if cursor:  # 아직 해당 객체가 메모리를 사용하고 있다면
      cursor.close() # 해제해준다.
   if conn:
      conn.close()
   print("예외 처리 및 프로그램 자원 해제 후, 완료!!") 
