'''
**1. 개요**
데이터베이스 연동 프로그래밍에서 데이터 수정(Update)은 가장 까다로우면서도 필수적인 작업입니다.
사용자의 실수를 방지하기 위해 기존 데이터를 화면에 먼저 보여주고,
변경이 필요한 부분만 안전하게 입력받아 데이터베이스에 반영하는 실무적인 패턴을 학습합니다.

**2. 전문용어로 정확한 핵심 개념**

* 단일 행 조회 (Single Row Fetch): 수정할 대상의 식별자(PK)를 통해
현재 상태를 DB에서 정확히 불러오는 과정입니다.
* 바인드 변수 (Bind Variable): SQL Injection과 같은 보안 위협을 방지하고 처리 속도를 높이기 위해,
SQL 문장에 값을 직접 입력하지 않고 변수(:1, :2 등)로 치환하여 처리하는 기법입니다.
* 트랜잭션 제어 (Transaction Management): UPDATE 명령 실행 후 데이터의 무결성을 보장하기 위해,
성공 시 COMMIT을 수행하고 에러 발생 시 ROLLBACK을 수행하는 데이터베이스 안전 장치입니다.

**3. 좀 더 쉽고 재미있는 핵심 키워드/코드 최고의 암기법**
수정 로직의 5단계 안전 흐름을 '조선확수결'로 암기해 보세요.

* 조: 전체 리스트 [조]회 (어떤 데이터가 있는지 파악)
* 선: 수정할 항목 [선]택 (Primary Key 입력)
* 확: 현재 데이터 [확]인 (기존 데이터 상세 조회)
* 수: 새로운 값으로 [수]정 (빈 값을 입력하면 기존 값 유지)
* 결: 수정된 [결]과 확인 (상세 조회를 다시 실행하여 검증)


CREATE TABLE HERO_MART (
    ITEM_ID NUMBER PRIMARY KEY,
    ITEM_NAME VARCHAR2(100),
    CATEGORY VARCHAR2(50),
    PRICE NUMBER,
    STOCK NUMBER,
    POWER_LEVEL NUMBER(3,1),
    STATUS VARCHAR2(20)
);

-- 초기 데이터 입력
INSERT INTO HERO_MART VALUES (1, '투명해지는 생수', '음식', 1500, 20, 5.5, '판매중');
INSERT INTO HERO_MART VALUES (2, '순간이동 망토', '의류', 50000, 5, 9.9, '판매중');
INSERT INTO HERO_MART VALUES (3, '화염 저항 장갑', '방어구', 25000, 10, 7.5, '준비중');
COMMIT;
'''

from  a00_con import dbCon as con
from dataclasses import dataclass
@dataclass
class DeptDTO:
    deptno:int
    dname:str
    loc:str

   
try:
   conn = con() # 연결객체
   cursor = conn.cursor()
   sql = '''
   UPDATE DEPT01
   SET DNAME=:dname,
       LOC=:loc
   WHERE DEPTNO = :deptno 
   '''
   dto = DeptDTO(10,'인사','서울') # 수정할 데이터 선언
   cursor.execute(sql, dto.__dict__)
   
   conn.commit()
   print("수정 성공")
      
except Exception as e:
   print("예외 발생:", e)
   if conn:
      conn.rollback() # 에러 발생 시 원복 처리   
finally:
   # 예외 상관없이
   if cursor:  # 아직 해당 객체가 메모리를 사용하고 있다면
      cursor.close() # 해제해준다.
   if conn:
      conn.close()
   print("예외 처리 및 프로그램 자원 해제 후, 완료!!") 
