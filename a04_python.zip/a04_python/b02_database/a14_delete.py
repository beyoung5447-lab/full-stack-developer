from  a00_con import dbCon as con
from dataclasses import dataclass
@dataclass
class DeleteDTO:
   deptno : int

   
try:
   conn = con() # 연결객체
   cursor = conn.cursor()
   sql = ''' delete FROM DEPT01 WHERE DEPTNO = :deptno '''
   dto = DeleteDTO(60)

   cursor.execute(sql, dto.__dict__)


   conn.commit()   
   print("성공")
except Exception as e:
   print("예외 발생:", e)
   if conn:
      conn.rollback() # 에러 발생 시 원복 처리   
finally:
   # 예외 상관없이
   if cursor:  # 아직 해당 객체가 메모리를 사용하고 있다면
      cursor.close() # 해제해준다.
   if conn:
      conn.close()
   print("예외 처리 및 프로그램 자원 해제 후, 완료!!") 
