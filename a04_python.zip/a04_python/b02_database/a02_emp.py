'''
## [초급 문제] 사내 인트라넷 구축: 전체 사원 정보 한 번에 불러오기

사내 인트라넷의 '직원 검색' 페이지를 만들고 있습니다.
오라클 DB에 접속하여 사원(EMP) 테이블의 모든 데이터를 가져오는 기본 코드를 작성하세요.

* 조건 1: `oracledb` 라이브러리를 사용하여 scott/tiger 계정으로 접속할 것.
* 조건 2: DB 접속 성공 시 커넥션의 버전 정보(version)를 출력할 것.
* 조건 3: 커서를 생성하고 `SELECT * FROM EMP` 쿼리를 실행할 것.
* 조건 4: `fetchall()` 메서드를 사용해 전체 데이터를 튜플 리스트 형태로 출력할 것.

'''
# 1. 모듈 호출
import oracledb
# 2. 오라클 접속
conn = oracledb.connect(user="scott",password="tiger",
                        dsn="localhost:1521/FREE")
# 3. 커서 객체 생성
cur = conn.cursor()
# 4. sql 작성
sql = '''
SELECT * FROM EMP
'''
# 5. 커서객체로 SQL 수행
cur.execute(sql)
# 6. 커서객체가 가지고 있는 fetchall() 리스트가져오기
empList = cur.fetchall()
# 7. 사원정보 리스트 출력
print("# 사원 정보 리스트 #\n", empList)





'''
## [중급 문제] 인사팀 연봉 분석: 급여 2500 이상 핵심 인재 명단 출력

인사팀에서 연봉 협상을 위해 급여(SAL)가 2500 이상인 핵심 인재 명단을 요청했습니다.
단순히 튜플 형태로 던져주면 인사팀에서 보기 어려우니,
데이터를 꺼내어 보기 좋게 가공하고 안전하게 DB 접속을 종료하는 실무 코드를 작성하세요.

* 조건 1: EMP 테이블에서 급여(SAL)가 2500 이상인 사원의 이름(ENAME), 직급(JOB), 급여를 조회.
* 조건 2: `fetchall()`로 데이터를 가져온 뒤, `for` 반복문을 사용하여 가공할 것.
* 조건 3: 출력 형식은 "사원명: OOO | 직급: OOO | 급여: OOO" 형태로 깔끔하게 만들 것.
* 조건 4: 모든 작업이 끝나면 커서(cursor)와 커넥션(connection)을 명시적으로 `close()` 할 것.

'''

import oracledb

# [중급 정답]
# 1. DB 접속 및 커서 생성
conn = oracledb.connect(user="scott", password="tiger", dsn="localhost:1521/FREE")
cur = conn.cursor()

# 2. 조건부 SQL 구문 작성 및 실행
sql = """
    SELECT ENAME, JOB, SAL 
    FROM EMP 
    WHERE SAL >= 2500
"""
cur.execute(sql)

# 3. fetchall()로 데이터를 가져온 후 for문으로 예쁘게 가공
high_salary_emps = cur.fetchall()

print("\n=== 핵심 인재 (급여 2500 이상) 명단 ===")
for emp in high_salary_emps:
    # 튜플의 인덱스(0, 1, 2)를 활용하여 각각의 데이터 추출
    name = emp[0]
    job = emp[1]
    sal = emp[2]
    print(f"사원명: {name} | 직급: {job} | 급여: {sal}")