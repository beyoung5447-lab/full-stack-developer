
'''
### 2. 초급 문제 (기본 등록 기능 구현)

#### [문제 설명]

제시된 히어로 등록 코드를 참고하여, `VillainDTO` 클래스를 데이터클래스로 선언하세요.
사용자로부터 빌런 이름, 위험도(정수), 발견 지역(문자열)을 입력받아 `VILLAIN` 테이블에 등록하는 파이썬 코드를 작성합니다.
딕셔너리 바인딩(`__dict__`), 예외 처리(`try-except-finally`), 트랜잭션 확정(`commit`/`rollback`), 자원 해제(`cursor`, `conn`) 패턴을 모두 포함해야 합니다.

'''

'''
   -- 빌런 정보 테이블 생성
CREATE TABLE VILLAIN (
    VILLAIN_CODE NUMBER PRIMARY KEY,
    VILLAIN_NAME VARCHAR2(100) NOT NULL,
    DANGER_LEVEL NUMBER(2) NOT NULL,
    DISCOVERY_LOC VARCHAR2(200) NOT NULL
);

-- 자동 번호 생성을 위한 시퀀스 생성
CREATE SEQUENCE VILLAIN_SEQ
    START WITH 1
    INCREMENT BY 1
    NOCACHE;
   
'''

from  a00_con import dbCon as con
from dataclasses import dataclass
@dataclass
class VallainDTO:
    villain_name:str
    danger_level:int
    discovery_loc:str

try:
   conn = con() # 연결객체
   cursor = conn.cursor()
   input_name = input("빌런 이름 입력(문자열):") 
   input_level = int( input("빌런 위험도 입력(정수):") ) 
   input_loc = input("빌런 지역 입력(문자열):") 
   new_villain = VallainDTO(input_name, input_level, input_loc)
   print(new_villain.__dict__)
   sql = '''
    INSERT INTO VILLAIN VALUES(VILLAIN_SEQ.NEXTVAL, 
     :villain_name,:danger_level,:discovery_loc)'''
   cursor.execute(sql, new_villain.__dict__)
   conn.commit()
   print("[성공] 빌런 ", new_villain.villain_name," 등록 완료!")
   
except Exception as e:
   print("예외 발생:", e)
   if conn:
      conn.rollback()
finally:
   # 예외 상관없이
   if cursor:  # 아직 해당 객체가 메모리를 사용하고 있다면
      cursor.close() # 해제해준다.
   if conn:
      conn.close()
   print("예외 처리 및 프로그램 자원 해제 후, 완료!!") 


