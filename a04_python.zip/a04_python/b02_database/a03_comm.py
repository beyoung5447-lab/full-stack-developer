'''
# DB 처리에서 공통 모듈 처리.
1. 연결부분은 일반적으로 공통 모듈로 선언해서 호출하는 것이 일반적이다.
   b02_database/a00_con.py 
   연결정보설정
2. try
   except
   예외 처리
3. 자원해제 .close()를 통해서 DB 연결자원(메모리)를 해제해주어 원활한 프로그램을
   처리해준다.

'''
# 같은 패키지에 있을 때 : from 모듈명 import 사용할구성요소 as 별칭명

'''
1. 데이터베이스 조건 검색 개요
여러분, 환영합니다. 오늘 우리는 방대한 데이터베이스의 바다에서
원하는 정보만 정확하게 건져 올리는 '데이터 필터링' 기술을 배웁니다.
실무 환경에서 수백만 건의 데이터를 모두 메모리로 가져오면 시스템이 다운될 수 있습니다.
따라서 SQL의 WHERE 절을 활용하여 필요한 데이터만 빠르고 안전하게
추출하는 방법을 익히는 것은 백엔드 개발자의 가장 중요한 필수 역량입니다.
2. 전문 용어로 알아보는 정확한 핵심 개념

1. 조건 필터링 (Condition Filtering)
SELECT 문에 WHERE 절을 추가하여 논리 연산 및 비교 연산의 결과가
참(True)인 데이터 행(Row)만 반환하도록 결과를 제한합니다.
2. 패턴 및 범위 검색 (Pattern & Range Search)
LIKE 연산자를 통해 특정 문자열 패턴을 포함하는 데이터를 검색하며,
BETWEEN 연산자로 지정된 범위 내의 데이터를 효율적으로 연속 조회합니다.
3. 프리페어드 스테이트먼트 (Prepared Statement)
사용자 입력값을 SQL 쿼리문에 직접 결합하지 않고, 매개변수(Bind Variable) 형태로
전달하여 해킹 기법 중 하나인 SQL 인젝션(SQL Injection)을 원천적으로 차단합니다.
4. DTO (Data Transfer Object) 패턴의 활용
파이썬의 dataclass를 활용하여 여러 개의 검색 조건을 하나의 객체로 캡슐화합니다.
이후 내부 속성인 __dict__를 통해 딕셔너리 형태로 안전하게 DB 계층에 전달합니다.

3. 빠르고 재미있는 핵심 키워드 최고의 암기법
실무에서 가장 많이 쓰는 4가지 핵심 요소를 'W.L.B.P'로 기억해 보세요.

* W (Where) : "어디서 찾을까?" (필터링 조건의 시작)
* L (Like) : "이런 패턴 좋아!" (문자열 부분 포함 검색, %키워드%)
* B (Between) : "너와 나 사이!" (시작과 끝 범위 검색)
* P (Prepared) : "보안 준비 완료!" (데이터는 변수명 :keyword 형식으로 안전하게 전달)

[핵심 코드 암기 공식]
sql = "SELECT * FROM 테이블 WHERE 컬럼명 LIKE :keyword"
execute(sql, keyword=실제데이터)
'''
# 사내 인트라넷 시스템 : 임직원 이름 검색
# 직원 이름의 일부만 입력해도 해당 직원을 신속하게 찾아주는 기능입니다.
# 이름에 특정 글자가 포함된 사원 찾기
# ename = input("검색할 사원명(일부)을 입력하세요")
# sql = '''
#  SELECT * FROM EMP
#  WHERE ENAME LIKE :keyword

# 입력한 ename을 키워드로 mapping 하여 비슷한 글자 검색(키워드 검색)을 처리할 수 있다.
# from  a00_con import dbCon as con
# conn = con()
# cursor = conn.cursor()
# print(cursor)
# cursor.execute(sql, keyword = f'%{ename}%')
# result = cursor.fetchall()
# print(result)


# 인사관 시스템 : 사원 담당 직문 부분 검색
job_keyword = input("검색할 직무명(일부) 입력:")
# LIKE 연산자와 :keyword 바인딩 변수를 활용한 sql 쿼리
sql = '''
SELECT * 
FROM EMP
WHERE JOB LIKE :schJob
'''
from  a00_con import dbCon as con
conn = con()
cursor = conn.cursor()
cursor.execute(sql,schJob=f'%{job_keyword}%')
rs = cursor.fetchall()
print(rs)
