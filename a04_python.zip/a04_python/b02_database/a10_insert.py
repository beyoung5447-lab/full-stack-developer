'''
### 3. 중급 문제 (조건부 조회 및 신규 빌런 등록 기능)

#### [문제 설명]

앞서 생성한 `VILLAIN` 테이블을 대상으로, 실무에서 데이터 중복을 방지하기 위해
자주 쓰이는 **조건부 등록(INSERT)** 기능을 구현하세요.

1. 사용자로부터 등록하려는 빌런의 고유 코드(`villain_code`)를 정수로 입력받습니다.
2. 입력받은 코드가 DB에 실제로 존재하는지 먼저 조회(`SELECT COUNT(*)`)합니다.
3. 조회 결과, 이미 존재하는 코드라면 "[알림] 존재하는 코드입니다."를 출력하고
아무 작업 없이 프로그램을 종료합니다. (등록 불가 처리)
4. 존재하지 않는 새로운 코드일 경우에만 이름, 위험도, 발견 지역을 추가로 입력받습니다.
5. 입력받은 데이터를 딕셔너리(`__dict__`)로 바인딩하여 `INSERT` 처리를 수행합니다.
6. 데이터클래스 활용, 트랜잭션, 예외 처리, 자원 해제 구조를 동일하게 유지하세요.
'''

from a00_con import dbCon as con
from dataclasses import dataclass

# 1. 등록 처리를 위해 빌런 코드까지 포함한 DTO 클래스 선언
@dataclass
class VillainInsertDTO:
    villain_code: int
    villain_name: str
    danger_level: int
    discovery_loc: str

try:
    conn = con()
    cursor = conn.cursor()
    
    # 2. 사용자로부터 신규 등록할 고유 코드 입력받기
    target_code = int(input("등록할 빌런 고유 코드 입력(정수): "))
    
    # 3. 해당 코드가 이미 DB에 존재하는지 카운트 조회
    check_sql = "SELECT COUNT(*) FROM VILLAIN WHERE VILLAIN_CODE = :code"
    cursor.execute(check_sql, {"code": target_code})
    count = cursor.fetchone()[0]
    
    # 4. 논리 처리: 존재하면 등록 불가, 존재하지 않으면 등록 진행
    if count > 0:
        # 이미 데이터가 있으므로 안내 후 종료 (INSERT 생략)
        print("[알림] 이미 존재하는 코드입니다. 등록을 종료합니다.")
    else:
        # 존재하지 않는 경우에만 추가 정보를 입력받아 등록 로직 수행
        input_name = input("빌런 이름 입력(문자열): ")
        input_level = int(input("위험도 입력(정수): "))
        input_loc = input("발견 지역 입력(문자열): ")
        
        # 입력된 데이터를 DTO 객체로 묶기
        new_dto = VillainInsertDTO(target_code, input_name, input_level, input_loc)
        print("등록 대기 데이터:", new_dto.__dict__)
        
        # DB 등록 SQL 실행 (입력받은 target_code를 그대로 반영)
        insert_sql = '''
            INSERT INTO VILLAIN (VILLAIN_CODE, VILLAIN_NAME, DANGER_LEVEL, DISCOVERY_LOC)
            VALUES (:villain_code, :villain_name, :danger_level, :discovery_loc)
        '''
        cursor.execute(insert_sql, new_dto.__dict__)
        
        # 트랜잭션 확정
        conn.commit()
        print("[성공] 새로운 빌런", new_dto.villain_name, "등록 완료!")

except Exception as e:
    print("예외 발생:", e)
    if conn:
        conn.rollback() # 에러 발생 시 원복 처리
finally:
    # 예외 발생 여부와 상관없이 메모리 해제
    if cursor:
        cursor.close()
    if conn:
        conn.close()
    print("예외 처리 및 프로그램 자원 해제 후, 완료!!")