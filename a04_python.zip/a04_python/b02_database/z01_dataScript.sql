CREATE TABLE HERO_MART (
    ITEM_ID NUMBER PRIMARY KEY,
    ITEM_NAME VARCHAR2(100),
    CATEGORY VARCHAR2(50),
    PRICE NUMBER,
    STOCK NUMBER,
    POWER_LEVEL NUMBER(3,1),
    STATUS VARCHAR2(20)
);

-- 초기 데이터 입력
INSERT INTO HERO_MART VALUES (1, '투명해지는 생수', '음식', 1500, 20, 5.5, '판매중');
INSERT INTO HERO_MART VALUES (2, '순간이동 망토', '의류', 50000, 5, 9.9, '판매중');
INSERT INTO HERO_MART VALUES (3, '화염 저항 장갑', '방어구', 25000, 10, 7.5, '준비중');
COMMIT;
select * from HERO_MART;

SELECT * FROM DEPT01;
UPDATE DEPT01
   SET DNAME='회계',
       LOC='제주'
  WHERE DEPTNO = 60;
COMMIT; 
/*
class DeptDTO:
    deptno:int
    dname:str
    loc:str

# 수정 처리
sql = '''
UPDATE DEPT01
   SET DNAME=:dname,
       LOC=:loc
  WHERE DEPTNO = :deptno
'''

*/
UPDATE HERO_MART
   SET ITEM_NAME = '윤이나는 망토',
       CATEGORY = '의류',
       PRICE = 7000,
       STOCK = 7,
       POWER_LEVEL = 7.7,
       STATUS = '준비중'
  WHERE ITEM_ID = 2; 
COMMIT;   
SELECT * FROM HERO_MART;     
/*
1. SQL 작성(조회, 등록, *수정, 삭제) 실행 - db 정상 확인
2. 이 테이블의 컬럼을 확인 dtO 구성
class HeroMartDTO:
    item_id:int
    item_name:str
    category:str
    price:int
    stock:int
    power_level:float
    status:str
3. 위 수행 sql을 mapping 선언..
sql = '''
UPDATE HERO_MART
   SET ITEM_NAME = :item_name,
       CATEGORY = :category,
       PRICE = :price,
       STOCK = :stock,
       POWER_LEVEL = :power_level,
       STATUS = :status
  WHERE ITEM_ID = :item_id
'''
4. 수정될 입력 객체를 생성
dto = HeroMartDTO(3, '냉기 저항 투구','방어구',30000,12,8.0,'판매중')


*/




SELECT * FROM DEPT01;
delete FROM DEPT01 WHERE DEPTNO = 90;
/*
sql = '''
delete FROM DEPT01 WHERE DEPTNO := deptno
'''
*/
COMMIT;