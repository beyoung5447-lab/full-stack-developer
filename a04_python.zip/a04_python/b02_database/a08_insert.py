'''
## 파이썬 데이터베이스 데이터 등록(INSERT) 처리: DTO와 바인딩 변수를 활용한 안전한 영구 저장

### 1. 학습 개요

소프트웨어를 개발할 때 사용자가 입력한 데이터를 데이터베이스에 안전하고 정확하게 저장하는
기능은 가장 핵심적인 과정입니다. 단순한 문자열 조합으로 쿼리를 만들면 보안상 큰 허점이
생길 수 있으며, 데이터 타입이 맞지 않아 에러가 발생할 수도 있습니다.

이번 시간에는 사용자로부터 데이터를 입력받아 유효성을 검증하고, DTO(Data Transfer Object) 객체와
SQL 바인딩 변수를 활용하여 오라클(Oracle) 데이터베이스에 안전하게 등록하는 표준 절차를 학습합니다.
보안성이 높고 유지보수가 편리한 실무형 데이터 등록 패턴을 완벽히 내 것으로 만들어 봅시다.

---

### 2. 전문 용어로 정확한 핵심 개념

1. 데이터 등록 5단계 프로세스
* 사용자 인터페이스를 통해 원시 데이터를 수집하고, DB 컬럼 타입에 맞추어 유효성 검사 및
형변환을 거친 뒤, SQL 인젝션을 방지하기 위한 바인딩 변수 처리, 쿼리 실행, 트랜잭션
확정(Commit)까지의 체계적인 흐름을 의미합니다.


2. SQL 바인딩 변수 (Parameterized Query)
* 쿼리의 구조와 실제 입력 데이터를 분리하여 전달하는 방식입니다. SQL 인젝션 보안 공격을
원천적으로 방지하고, 데이터베이스가 쿼리 실행 계획을 재사용할 수 있게 도와줍니다.


3. 트랜잭션 확정 (Commit)
* 메모리 영역에서 임시로 처리된 데이터 변경 사항을 실제 디스크에 영구적으로 반영하여
데이터의 무결성과 일관성을 보장하는 작업입니다.



---

### 3. 직관적인 핵심 키워드와 최고의 암기법

[암기 비법: "수집하고, 검증하고, 바인딩(Binding) 걸어서 커밋(Commit)하자!"]

* 수: 사용자 입력값 수집 (Input)
* 검: 데이터 타입 및 무결성 검증/형변환 (Validation)
* 바: SQL 바인딩 변수로 안전하게 장착 (`:변수명` 또는 `__dict__`)
* 커: 트랜잭션 확정 영구 저장 (`commit()`)

적용 코드 패턴:


sql = "INSERT INTO 테이블명 VALUES(:속성명1, :속성명2)"
cursor.execute(sql, dto객체.__dict__)
conn.commit()

CREATE TABLE HERO (
    HERO_CODE NUMBER(4) PRIMARY KEY,
    HERO_NAME VARCHAR2(100) NOT NULL,
    HERO_EMAIL VARCHAR2(150),
    AGE NUMBER(3)
);


'''

from  a00_con import dbCon as con
from dataclasses import dataclass
# 히어로 정보 바탕으로 dto 클래스 선언
@dataclass
class HeroDTO:
   hero_name:str
   hero_email:str
   age:int

try:
   conn = con() # 연결객체
   cursor = conn.cursor()
   # 사용자 인터페이스를 통해 데이터 수집 및 유효성 검사(형변환)
   #input_code = int(input("히어로 고유 코드 입력(정수):"))
   input_name = input("히어로 이름 입력(문자열):")
   input_email = input("히어로 이메일 입력(문자열):")
   input_age = int(input("히어로 나이 입력(정수):"))
   # 수입된 데이터를 DTO객체 묶기
   new_hero = HeroDTO(input_name, input_email, input_age)
   # 등록 대기 중엔 데이터 구조
   print(new_hero.__dict__)
   sql = '''
    INSERT INTO HERO VALUES (HERO_SEQ.nextval,:hero_name,:hero_email, :age)
   '''
   # dictionary 형태의 key/value값이 입력의 :속성으로 mapping되어 입력 된다.
   cursor.execute(sql,new_hero.__dict__)
   # 트랜잭션 확정
   conn.commit()
   print("[성공]히어로 ", new_hero.hero_name,'등록!!')
 
except Exception as e:
   print("예외 발생:", e)
   if conn:
      conn.rollback() # 에러발생시, commit()되기전에는 원복이 가능하게 코드처리합니다.
finally:
   # 예외 상관없이
   if cursor:  # 아직 해당 객체가 메모리를 사용하고 있다면
      cursor.close() # 해제해준다.
   if conn:
      conn.close()
   print("예외 처리 및 프로그램 자원 해제 후, 완료!!")   





