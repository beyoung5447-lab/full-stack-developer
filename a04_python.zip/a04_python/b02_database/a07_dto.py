'''
파이썬 데이터베이스 연동: DTO를 활용한 데이터 객체 지향 최적화 

1. 학습 개요
이전 과정에서 배운 튜플 인덱스(예: row[0], row[1]) 방식은 컬럼 순서가 바뀌면 치명적인
오류를 유발합니다. 본 과정에서는 데이터를 의미 있는 이름으로 다룰 수 있도록
DTO(Data Transfer Object) 클래스를 도입하여 코드를 최적화하는 기법을 학습합니다.
이를 통해 가독성을 극대화하고 유지보수가 쉬운 실무형 코드를 작성할 수 있습니다.
2. 전문 용어로 정확한 핵심 개념

1. DTO(Data Transfer Object): 데이터베이스 레코드의 각 컬럼 데이터를 담아
애플리케이션 계층 간에 안전하고 편리하게 전달하기 위해 사용하는 데이터 컨테이너 객체입니다.
2. 데코레이터(@dataclass): 파이썬 3.7부터 지원되며, **init** 메서드 등을 자동으로 생성하여
코드 양을 획기적으로 줄여주는 DTO 클래스 전용 기능입니다.
3. 언패킹 연산자(*): DB에서 조회한 튜플 데이터를 DTO 객체로 생성할 때, 튜플의 요소를
객체의 매개변수로 자동 분리하여 매핑해주는 파이썬의 강력한 연산자입니다.

3. 쉽게 외우는 핵심 키워드와 암기법
[암기 비법: "인덱스는 가라! 별(*)이 빛나는 D.T.O 매핑"]
숫자(0, 1, 2)로 데이터를 부르지 말고, 이름(name, age)으로 우아하게 부릅시다.

* D: DB 데이터를
* T: 튜플 언패킹(*)을 사용해서
* O: Object(객체) 리스트로 깔끔하게 변환!
적용 코드: dto_list = [MyDTO(*row) for row in result_list]

4. 데이터베이스 테이블 및 초기 데이터 구축 스크립트
글로벌 유니콘 기업을 꿈꾸는 스타트업 관리 시스템을 실습 테이블로 준비합니다.


-- 실무 실습용 테이블 및 데이터 생성
CREATE TABLE TBL_STARTUP_TEAM (
    TEAM_ID NUMBER(4) PRIMARY KEY,
    TEAM_NAME VARCHAR2(100),
    CORE_TECH VARCHAR2(100),
    FUNDING NUMBER(10)
);

INSERT INTO TBL_STARTUP_TEAM VALUES (101, '오로라컴퓨팅', '양자컴퓨터', 90000);
INSERT INTO TBL_STARTUP_TEAM VALUES (102, '비전오토', 'AI자율주행', 75000);
INSERT INTO TBL_STARTUP_TEAM VALUES (103, '에코플래닛', '친환경신소재', 45000);
INSERT INTO TBL_STARTUP_TEAM VALUES (104, '스페이스X', '우주항공', 99000);

COMMIT;


'''
'''
# DTO 객체 변환 최적화
조회한 데이터를 단순히 튜플리스트로 두지 않고, DTO 객체 리스트로 변환하여
속성명으로 안전하게 접근하는 최적화 코드입니다.
1. 기본 사용 방법
   - 테이블 구조를 확인(컬럼과 데이터유형 ==> 속성명과 데이터타입 설정)
        CREATE TABLE TBL_STARTUP_TEAM (
            TEAM_ID NUMBER(4) PRIMARY KEY,
            TEAM_NAME VARCHAR2(100),
            CORE_TECH VARCHAR2(100),
            FUNDING NUMBER(10)
        );
     클래스 StartupDTO
     속성 team_id : int
          team_name : str
   - @dataclass : from dataclasses import dataclass
2. 컴프리핸션으로 객체형 List 만들기..
    1) fetchall()  : [(데이터1, 데이터2....),()] 
    2) 효과적인 객체현 List [ StartDTO(데이터1...),StartDTO(데이터1...),
                        StartDTO(데이터1...),]
    3) for team in startList:
          team.team_id
          team.team_name
          ...
          각 객체가 가지고 있는 속성명이 테이블 컬럼명이기에 
          데이터를 효과적으로 식별 및 활용을 할 수 있습니다.
    4) 컴프리핸션 처리 방법
       [] 배열 선언과 동시에 for문을 내부적으로 사용하면 배열 구조를 만들어준다.
       ex) [ for cnt in range(1,11)] ==> [1,2,3,.... 10]    
       [] 객체형 배열만들기..
       dto_list = [StartupDTO(*row) for row in rsult_rows]
          rsult_rows : fetchall() 만들어진 튜플 리스트 
            [(101, '오로라컴퓨팅', '양자컴퓨터', 90000), (), ()]                          
            
            (101, '오로라컴퓨팅', '양자컴퓨터', 90000) ==> row

            StartupDTO(*row)  StartupDTO(row[0],row[1],row[2])
            객체가 생성되어 데이터가 순서대로 속성값에 생성자로 할당 된다.

            dto_list ==> [StartupDTO(), StartupDTO(), StartupDTO()]
            데이터가 들어가 객체가 차곡차곡 쌓인다.

        CREATE TABLE TBL_STARTUP_TEAM (
            TEAM_ID NUMBER(4) PRIMARY KEY,
            TEAM_NAME VARCHAR2(100),
            CORE_TECH VARCHAR2(100),
            FUNDING NUMBER(10)
        );
            
'''

from  a00_con import dbCon as con
from dataclasses import dataclass

# 1. 테이블 구조와 완벽히 일치하는 DTO 클래스 선언
@dataclass
class StartupDTO:
   team_id: int
   team_name: str
   core_tech: str
   funding: int

try:
   conn = con() # 연결객체
   cursor = conn.cursor()
   sql = "SELECT * FROM TBL_STARTUP_TEAM"
   cursor.execute(sql)
   result_rows = cursor.fetchall()  # 튜플형 리스트
   # 핵심 최적화 : 튜플형리스트를 DTO 객체 리스트로 일괄 변환(언패킹 * 활용)
   dto_list = [StartupDTO(*row) for row in result_rows]  # 객체(StartupDTO)를 포함한 리스트
   for team in dto_list:
      # 최적화 결과 : 인덱스 [0], [1]  ==> 속성명 접근 출력
      print(team.team_id,end="\t")
      print(team.team_name,end="\t")
      print(team.core_tech,end="\t")
      print(team.funding)
   
   
except Exception as e:
   print("예외 발생:", e)
finally:
   # 예외 상관없이
   if cursor:  # 아직 해당 객체가 메모리를 사용하고 있다면
      cursor.close() # 해제해준다.
   if conn:
      conn.close()
   print("예외 처리 및 프로그램 자원 해제 후, 완료!!")   


'''
-- 실무 실습용 테이블 및 데이터 생성: 우주 특급 배송 시스템
CREATE TABLE TBL_SPACE_DELIVERY (
TRACK_ID NUMBER(4) PRIMARY KEY,
SHIP_NAME VARCHAR2(100),
DESTINATION VARCHAR2(100),
CARGO_WGT NUMBER(10)
);

INSERT INTO TBL_SPACE_DELIVERY VALUES (1001, '밀레니엄팔콘', '안드로메다', 8500);
INSERT INTO TBL_SPACE_DELIVERY VALUES (1002, '비바스타', '화성', 3200);
INSERT INTO TBL_SPACE_DELIVERY VALUES (1003, '갤럭시익스프레스', '토성', 9500);
INSERT INTO TBL_SPACE_DELIVERY VALUES (1004, '코스모호', '달', 1500);
COMMIT;

'''

'''
**[초급 문제: 우주 화물 DTO 변환 작전!]**
위 테이블 데이터를 담을 DTO 클래스(SpaceDTO)를 `@dataclass`로 선언하세요.
그런 다음 DB에서 가져온 튜플 리스트(`result_rows`)를 객체 리스트로 만드세요.
리스트 컴프리헨션과 언패킹(`*`)을 사용하여 한 줄로 DTO 변환을 수행하는 것이 핵심입니다.

'''
from dataclasses import dataclass
@dataclass
class SpaceDTO:
    track_id: int
    ship_name: str
    destination: str
    cargo_wgt: int
from  a00_con import dbCon as con
try:
   conn = con() # 연결객체
   cursor = conn.cursor()
   sql = '''SELECT * FROM TBL_SPACE_DELIVERY'''
   cursor.execute(sql)
   result_rows = cursor.fetchall()
   dto_list = [SpaceDTO(*row) for row in result_rows]
   for ship in dto_list:
      print(ship.track_id,end="\t")
      print(ship.ship_name,end="\t")
      print(ship.destination,end="\t")
      print(ship.cargo_wgt)

   
   
except Exception as e:
   print("예외 발생:", e)
finally:
   # 예외 상관없이
   if cursor:  # 아직 해당 객체가 메모리를 사용하고 있다면
      cursor.close() # 해제해준다.
   if conn:
      conn.close()
   print("예외 처리 및 프로그램 자원 해제 후, 완료!!")   


'''
**[중급 문제: 우주선 화물 필터링 및 관제 시스템 구축!]**
DB 연결부터 예외 처리, 자원 해제까지 포함된 실무형 코드를 작성하세요.
조건 1: 화물 무게(CARGO_WGT)가 5000 이상인 우주선 데이터만 가져오세요.
조건 2: 가져온 데이터를 DTO 리스트로 변환하고, f-string을 써서 속성명으로 출력하세요.
조건 3: `try-except-finally` 구문을 활용하여 에러 처리 및 DB 자원 해제를 완벽히 하세요.
'''