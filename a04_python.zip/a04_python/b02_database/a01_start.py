'''
[데이터베이스 연동 완벽 마스터 교안]

1. 개요 (Overview)
파이썬으로 데이터베이스(DB)를 다루는 것은 거대한 정보 도서관에 정식으로 가입하여 원하는 책을
안전하고 빠르게 빌려오는 과정과 같습니다. 수많은 데이터를 규격화하여 보관하고, 필요할 때마다
파이썬 코드로 불러와 분석이나 서비스에 활용하는 데이터 엔지니어링의 첫걸음입니다.
2. 최고 효율 암기법: 5단계 프로세스 (접·장·실·인·닫)
유명한 맛집(식당)에서 요리를 주문하는 상황을 상상해 보세요. 파이썬 DB 연동도 이와 똑같습니다.
* 1. 접(Connection) : 접속하기 (식당 문을 열고 입장하여 자리에 앉음)

* 2. 장(Cursor) : 장바구니/커서 (나의 주문을 주방에 전달할 전담 점원 호출)

* 3. 실(Execute) : 실행하기 (원하는 메뉴가 적힌 주문서(SQL)를 점원에게 전달)

* 4. 인(Fetch/Commit) : 인출 및 인증 (완성된 요리를 받거나(Fetch), 계산을 확정(Commit))

* 5. 닫(Close) : 닫기 (식사를 마치고 식당 문을 닫고 안전하게 퇴장)



* 교육용 암기 팁: "접장(점장)님이 실무를 인수하고 닫는다 (접·장·실·인·닫)"

3. 전문 용어와 정확한 핵심 개념

* API/Driver (oracledb) : 파이썬과 특정 DB 사이를 완벽하게 연결해 주는 공식 통역사입니다.
* Thick 모드 : 'Oracle Instant Client'라는 전용 번역기를 PC에 직접 설치하고,
코드에서 그 경로(lib_dir)를 명시하여 연결하는 전통적이고 강력한 접속 방식입니다.
* Connection : DB 서버와 파이썬 프로그램 사이에 뚫린 실제 물리적인 데이터 고속도로입니다.
* Cursor : 고속도로를 타고 DB 내부에 들어가 SQL 문장을 실행하고 결과를 담아오는 객체입니다.
* Fetch : 커서가 DB에서 찾은 데이터를 파이썬 메모리로 꺼내는 인출 작업입니다.
(fetchone: 한 줄씩 순차적으로 꺼냄 / fetchall: 조건에 맞는 모든 행을 한 번에 꺼냄)

4. 실무 밀착형 예제 코드
여러분이 회사의 인사팀(HR) 데이터 분석가가 되어, 오라클 DB에 접속해 우수 사원 명단을
가져오는 상황입니다. 안정성을 위해 예외 처리(try-except)까지 적용한 실전 코드입니다.

```python
import oracledb as oci

# 1. Thick 모드 초기화 (Instant Client 설치 경로 지정)
lib_dir_path = r'C:\instantclient_21_20'
oci.init_oracle_client(lib_dir=lib_dir_path)

con = None
try:
    # [접] Connection: DB 서버 접속 (계정/비번@서버주소:포트/DB명)
    con = oci.connect("scott/tiger@localhost:1521/xepdb1")
    print("DB 연결 성공! 오라클 버전:", con.version)

    # [장] Cursor: SQL을 실행하고 결과를 담을 커서 객체 생성
    cursor = con.cursor()

    # [실] Execute: 실행할 SQL 작성 및 처리 (급여가 3000 이상인 사원 조회)
    sql = "SELECT EMPNO, ENAME, SAL FROM EMP WHERE SAL >= 3000"
    cursor.execute(sql)

    # [인] Fetch: 데이터 인출 (fetchall을 사용하여 한 번에 리스트로 가져옴)
    rows = cursor.fetchall()
    print("\n=== VIP 우수 사원 명단 ===")
    for row in rows:
        print(f"사번: {row[0]}, 이름: {row[1]}, 급여: {row[2]}")

except Exception as e:
    print("DB 처리 중 에러 발생:", e)
finally:
    # [닫] Close: 자원 반환 및 접속 종료 (에러가 나도 반드시 실행됨)
    if con:
        con.close()
        print("DB 연결을 안전하게 종료했습니다.")

```
'''
# 데이터 베이스 접속 처리..
import oracledb
# 오라클 접속 및 커서 객체 생성..
conn = oracledb.connect(user="scott", 
                        password="tiger", 
                        dsn="localhost:1521/FREE")
print("1. 기본 접속 처리 성공 버젼 정보",conn.version)
cur = conn.cursor()
print("2. 커서객체", cur)
# sql 작성(select 구문)을 통해서 데이터 가져오기 처리..
sql = '''
   SELECT * FROM DEPT
'''
# 커서객체로 SQL 수행 ==> 내부적으로 정상적인 접속과 기본 수행이 끝나면 데이터가 쌓인다.
cur.execute(sql)
# 커서객체가 가지고 있는 fetchall() 메서드를 통해서 데이터 가져오기..
deptList = cur.fetchall()
print("부서정보 리스트(튜플형)")
print(deptList)

