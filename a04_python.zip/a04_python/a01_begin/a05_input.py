'''
# 파이썬에서 콘솔창으로 데이터 입력
1. input() 함수
   키보드로 콘솔창(화면결과출력창)에서 데이터를 입력하게 하는 함수입니다.
2. 활용
    1) 변수를 지정해서 할당 및 처리해줍니다.
      변수 = input("화면에 출력할 안내 내용")
      ex)
      name = input('이름을 입력하세요')
    2) 기본적으로 입력된 데이터는 문자열이고, 위와같이 msg와 함께 입력을 기다렸다가
     입력 후, enter키를 처리하면 name에 입력된 데이터를 할당합니다.
    3) 숫자형 데이터를 입력해서, 연산 처리하게 할려면 입력된 데이터를 형변환 처리함수로
    처리하여야 합니다. 문자열 ==> 숫자형(int())
    price = int(input("금액입력" ))
    dia = float(input("반지름입력)) 
    input() 문자열 입력 함수 ==> int()/float() 숫자형 변환함수 적용.   

'''
#name = input("이름을 입력하세요!!")
#print('입력된 이름:', name)
# ex) 좋아하는 과일의 이름을 입력받아서 출력하세요
#fruit = input("좋아하는 과일의 이름을 입력하세요:")
#print("내가 좋아하는 과일은 ", fruit)
priceStr = input("과일의 가격 입력:")
price = int(priceStr) # 숫자형 문자열 '25' ==int()==> 숫자 25
cnt = 5
print("총비용:", price*cnt)
'''
price = int(input("과일의 가격 입력:"))  : 입력받은 내용을 바로 숫자로 변환처리

'''
# ex) 국어, 영어, 수학 점수를 입력 받아서 총계와 평균 점수를 출력하세요

kor = int(input("국어 점수:"))
eng = int(input("영어 점수:"))
math = int(input("수학 점수:"))
tot = kor + eng + math
avg = tot//3 # 정수형만 뽑아서 처리
print(f''' # 성적표 #
국어 : {kor}점
영어 : {eng}점
수학 : {math}점
총점 : {tot}점
평균 : {avg}점''')


