
# pip install fastapi uvicorn
from fastapi import FastAPI
from fastapi.responses import HTMLResponse

app = FastAPI()

# http://localhost:5000/receive?st_name=홍길동&kor_score=70
@app.get('/receive', response_class=HTMLResponse)
def receive_data(st_name: str = '', kor_score: str = ''):
    return f"<h2>수신 완료</h2>이름: {st_name}, 점수: {kor_score}"

# ?name=양현수&email=zelratole%40gmail.com&phone=0105559736&myIntro=안녕하세요.+%0D%0A양현수입니다
@app.get('/profile', response_class=HTMLResponse)
def receive_data(name: str = '', 
                 email: str = '',
                 phone: str = '',
                 myIntro: str = ''
                 ):
    return f'''<h2>나의 프로필</h2>
            이름: {name}, 
            이메일: {email},
            전화번호: {phone},
            나의소개: {myIntro}
            '''
# http://localhost:5000/diary
# http://localhost:5000/diary?date=2026-10-07&title=오늘은+좋은날&content=하루를+마감하면서%0D%0A좋은+생각들이+났다..
@app.get('/diary', response_class=HTMLResponse)
def receive_data(date: str = '', 
                 title: str = '',
                 content: str = ''
                 ):
    return f'''<h2>저장된 오늘의 일기</h2>
            날짜: {date}<br> 
            제목: {title}<br>
            내용: {content} '''

if __name__ == '__main__':
    import uvicorn
    uvicorn.run(app, host='127.0.0.1', port=5000)


