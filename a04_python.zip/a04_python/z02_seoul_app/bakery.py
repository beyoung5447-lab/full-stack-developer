# --------------------------------------------------
# a04_python/z02_seoul_app/bakery.py 
# (맛집 배달 앱의 빵과 커피를 책임지는 파일)
# --------------------------------------------------

# 1. 빵을 만드는 클래스 (설계도)
class Croissant:
    # 초기 설정 (이름과 가격)
    def __init__(self, name, price):
        self.name = name
        self.price = price

    # 먹는 기능 (메서드)
    def eat(self):
        print(f"🥐 {self.name}({self.price}원)을 바삭하게 먹습니다!")


# 2. 커피를 만드는 함수
# (클래스 밖에 독립적으로 만들어진 일반 함수입니다)
def make_coffee(menu_name):
    print(f"☕ 얼음 동동 {menu_name} 완성!")