import numpy as np
from sklearn.linear_model import LogisticRegression
# 1 단계 데이터 준비하기

# 2 단계 로지스틱 회귀 모델 학습

# 3 단계 새로운 데이터 예측하는
#   0) 테스트 데이터
#   1) 확률
#   2) O/X 결과

# 4 단계 출력
'''
[연습 1] 쇼핑몰 리뷰 감성 분석 (글자 수)
데이터(X): 리뷰 글자 수 (10, 20, 50, 100, 150)
결정 여부(y): "악플", "악플", "선플", "선플", "선플"  악플 0, 선플 1
미션: X와 y를 Numpy 배열로 만들어 보세요.
'''
review_len = np.array([10,20,50,100,150]).reshape(-1,1)
print("데이터 X:\n", review_len)
review_status = np.array([0,0,1,1,1])
print("결정여부y:", review_status)
# 2 단계 로지스틱 회귀 모델 학습
model = LogisticRegression()
# AI에게 푼 문제 수와 합격 여부의 패턴을 주고 스스로 학습하게 합니다.
model.fit(review_len, review_status)

# 3 단계 새로운 데이터 예측하는  테스트할 글자수: 40글자 리뷰
#   0) 글자수 지정
new_review = np.array([[40.0]])
#   1) 확률
prob_review = model.predict_log_proba(new_review)[:,1] #  [:,1] : 2차원으로 행은 : 열이1개. 
print("확률:",prob_review)
#   2) O/X 결과
reviewOX = model.predict(new_review)
print("O/x - 1/0 :", reviewOX)





'''
[연습 2] 맛집 웨이팅 포기 예측 (대기 시간)

데이터(X): 대기 시간(분) (10, 20, 30, 40, 50)

결정 여부(y): "기다림", "기다림", "포기", "포기", "포기"

미션: X와 y를 Numpy 배열로 만들어 보세요.
'''
wait_time = np.array([10, 20, 30, 40, 50]).reshape(-1, 1)
wait_status = np.array([1, 1, 0, 0, 0]) # # 기다림1, 포기0
# 2 단계 로지스틱 회귀 모델 학습
mode_wait = LogisticRegression()
mode_wait.fit(wait_time, wait_status)
# 3 단계 새로운 데이터 예측하는
#   0) 테스트 데이터   (35분)
new_wait = np.array([[35.0]])
#   1) 확률
prob_wait = mode_wait.predict_proba(new_wait)[:,1]
#   2) O/X 결과
pred_wait = mode_wait.predict(new_wait)

'''
[연습 3] 중고마켓 사기꾼 판별 (가입 일수)

데이터(X): 가입 일수 (1, 3, 10, 30, 100)

결정 여부(y): "사기의심", "사기의심", "정상", "정상", "정상"

미션: X와 y를 Numpy 배열로 만들어 보세요.
'''
join_days = np.array([1, 3, 10, 30, 100]).reshape(-1, 1)
user_status = np.array([1, 1, 0, 0, 0]) #  사기의심1, 정상0
# 2 단계 로지스틱 회귀 모델 학습
model_fraud = LogisticRegression()
model_fraud.fit(join_days, user_status)

# 3 단계 새로운 데이터 예측하는
#   0) 테스트 데이터  가입일 수 5일
new_user = np.array([[5.0]])
#   1) 확률
prob = model_fraud.predict_proba(new_user)[:,1] 
#   2) O/X 결과
ox = model_fraud.predict(new_user)

'''
스마트팜 딸기 출하 판별 (일조량)
데이터(X): 일조량(시간) (2, 4, 6, 8, 10)
결정 여부(y): "출하불가", "출하불가", "출하가능", "출하가능", "출하가능"  출하불가 0, 출하가능 1
미션: X와 y를 Numpy 배열로 만들어 보세요.
'''
# 1단계 데이터
sun_hours = np.array([2, 4, 6, 8, 10]).reshape(-1,1)
farm_status = np.array([0,0,1,1,1])
# 2단계 로지스틱회귀 생성 학습(fit)
model = LogisticRegression()
model.fit(sun_hours, farm_status)
# 3단계 테스트 데이터 일조량 9시간으로 
test = np.array([[9.0]])
#   - 출하가능 확률
#print(model.predict_proba(test))
prob = model.predict_proba(test)[:,1] # [:,1] 출하불가 확률,  출하가능 확률 
#   - 출하여부 결정(0,1)
pre = model.predict(test)
# 4단계 출력
print("일조량:", test[0][0],"시간일 때")
print(f"출하 가능(1) 확률:{prob[0]*100:.2f}%")
print("출하 여부(0 또는 1):", "출하가능" if pre[0]==1 else "출하불가")



