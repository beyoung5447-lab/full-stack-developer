'''
# 빅데이터 알고리즘
1. 사용하는 이유
    1) 데이터 분석 및 패턴 인식
        - 빅데이터에서는 방대한 양의 데이터를 처리하고 분석해야 하므로, 효율적인
        알고리즘이 필요합니다.
        - 알고리즘은 데이터를 분류, 예측, 클러스트링 등 다양한 방식으로 처리하여,
        데이터를 의미 있는 정보로 변환하는데 중요한 역할을 합니다.

    2) 자동화와 최적화
        - 빅데이터에서 발생하는 복잡한 문제를 해결하기 위해 자동화된 시스템을 구축할
        수 있습니다.
        - 알고리즘을 통해 수작업을 줄이고, 최적화된 결과를 얻을 수 있습니다.
    3) 효율성
        - 데이터 양이 커지면 기존의 수작업 방식으로 처리하기 어려워집니다. 알고리즘은
        효율적인 데이터 처리를 통해 빅데이터 분석을 가능하게 합니다.
    4) 실시간 처리
        - 실시간 분석이 필요한 경우, 알고리즘을 통해 데이터를 즉시 처리하고 즉각적인
        의사결정을 할 수 있습니다.

2. 주요 알고리즘과 실무에서의 연관관계
    1) KNN(최근접 이웃 - K-Nerest Neighbors)
       - 실무 연관 관계 : 추천 시스템, 분류 문제
       - 적용 분야 : 고객 선호도를 예측하는 추천 시스템, 상품 분류 등
       - 핵심 아이디어 : K개의 가까운 이웃을 찾아 데이터를 분류하거나 예측
       - 핵심 파이썬 코드
           KNN모델 : knn = KNeighborsClassfier(n_neighbors=5)
                     knn.fit(X_train, y_train)  
                     # X_train, y_train 기존의 학습결과 데이터 
                     # .fit() Knn알고리즘에 의해서 기존에 있는 결과데이터를 학습시킴
                    예측  : X_test - 예측을 해야할 데이터
                     y_pred = knn.predict(X_test) : y_pred - 예측된 결과값
                    정확도 평가  accuracy = accuracy_score(y_test,y_pred);
                     print("정확도", accuracy)
    2) 서포트 벡터 머신(Support Vector Machine, SVM)
        - 실무 연관 관계 : 이미지 분석, 스팸 이메일 분석, 의류 데이터 분석
        - 적용 분야 : 텍스트, 이미지 분류 문제에 매우 효과적
        - 핵심 아이디어 : 최적의 분류 경계(Hyperplan)를 찾는 알고리즘
        - 핵심 코드 : svm = SVC(kernel="linear")  
    3) 랜덤 포레스트(Random forest) CRM 연관관계 있음
        - 실무 연관 관계 : 금융분야 신용 평가, 마케팅 분석, 질병 예측
        - 적용 분야 : 다양한 예측 문제에 강력하여, 
            앙상블(여러 모델 통합) 학습을 통해 더 높은 정확도 재고
        - 핵심 아이디어 : 여러 결정 트리를 결합하여 예측 정확도 향상
        - 핵심 코드 :  rf = RandomForestClassifier(n_estimators=10)
    4) 주성분 분석(Principal Component Anlysis) PCA
        - 실무 연관 관계 : 데이터 차원 축소, 특징 추출, 이미지 압축
        - 적용 분야 : 고차원 데이터를 저장하여 반환함. 분석 효율성을 높임
        - 핵심 아이디어 : 주요 성분을 추출하여 데이터의 차원을 축소
        - 핵심 코드 : pca = PCA(n_component=2)
                     X_pca = pca.fit_transform(X_train)



pip install python-dotenv notebook numpy pandas scikit-learn tensorflow torch torchvision matplotlib seaborn transformers oracledb 
'''
# sciket-learn 라이브러리의 datasets 모듈에서 붓꽃(iris) 데이터를 불러오는
# load_iris 함수를 가져옵니다.
from sklearn.datasets import load_iris
import pandas as pd
# 샘플 데이터 로딩
# 함수를 실행하여 붓꽃 데이터셋 전체를 iris라는 변수에 저장합니다.
iris = load_iris()
print("# iris 데이터 전체 #\n", iris)
x = iris.data
y = iris.target
# 2차원의 테이블 형태의 데이터로 변환해서 사용
df = pd.DataFrame(data=x, columns=iris.feature_names)
print("# 샘플 데이터 프레임 #")
print(df)
'''
1) iris.data : 데이터셋에서 머신러닝 모델 학습에 사용될 특징(Feature) 데이터만
추출하여 x에 저장합니다. 붓꽃의 꽃받침과 꽃잎의 길이/너비 수치 데이터가 이에 해당합니다.
 sepal length (cm)  sepal width (cm)  petal length (cm)  petal width (cm)
 꽃받침의 세로길이   꽃받침의 가로길이  꽃잎의 세로길이     꽃잎의 가로길
2) iris.target : 예측해야 할 정답(Label) 데이터를 추출하여 y에 저장합니다.
붓꽃의 3가지 품종 0, 1, 2라는 숫자로 매핑되어 있습니다.
0(setosa-부채붓꽃)
1(versicolor-변색붓꽃)
2(virginica-버지니아붓꽃)
3) 데이터브레임에 할당.
pd.DataFrame(x, columns=iris.feature_names) : 다차원 숫자 배열 형태의 x데이터를
보기 좋은 2차원 표 형태인 Pandas DataFrame으로 변환합니다. 이때 표의 각 열(column)
이름을 데이터셋에 포함된 iris.feature_names를 활용해 직관적으로 지정합니다.
'''
print("target 기본 raw 데이터")
print(iris.target)
df["target"] = iris.target
# 0, 1, 2 ==> 부채붓꽃, 변색붓꽃, 버지니아붓꽃 으로 설정하기 위한 선언
target_names = {0:"부채붓꽃",1:"변색붓꽃",2:"버지니아붓꽃"}
# 새로운 컬럼 label에 위에 조건에 따른 이름을 map()메서드에 의해 설정해서 추가 처리
df['label'] = df['target'].map( target_names )
print("전체데이터의 head만 확인")
print(df.head())
print(df)

