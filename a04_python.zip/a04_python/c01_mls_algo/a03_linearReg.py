'''
**[초급 연습문제] : 기본 개념과 코드 적용**
* 주제: 교육 서비스 기업의 학습 시간 대비 성취도 예측
* 상황: 수강생들의 주당 학습 시간(시간)에 따른 자격증 시험 점수 데이터를 확보했습니다.
* 데이터:
* 학습 시간(x): 2, 3, 5, 7, 8, 10
* 시험 점수(y): 55, 60, 70, 80, 85, 95
* 문제: 위 데이터를 바탕으로 선형 회귀 모델을 학습시키고, 특정 학생이 주당 **9시간**을
학습했을 때 기대되는 시험 점수를 예측하는 파이썬 코드를 작성해 보세요.
'''
import numpy as np
from sklearn.linear_model import LinearRegression
# 1. 데이터 준비(x는 반드시 2차원 배열로 변환)
study_hours = np.array([2, 3, 5, 7, 8, 10]).reshape(-1,1)
test_scores = np.array([55, 60, 70, 80, 85, 95])
# 2. 모델 생성 및 학습
model = LinearRegression()
model.fit(study_hours, test_scores)
# 3. 9시간 학습 시 점 예측
target_hour = np.array([[9]])
predicted_score = model.predict(target_hour)
# 4. 결과 출력
print(f"주당 9시간 학습시, 예측되는 시험 점수: 약{predicted_score[0]:.1f}점 입니다")

import numpy as np
from sklearn.linear_model import LinearRegression

# 1. 데이터 준비
ad_spending = np.array([10, 15, 20, 25, 30]).reshape(-1, 1)
downloads = np.array([12, 19, 23, 28, 31])

# 2. 모델 생성 및 학습
model = LinearRegression()
model.fit(ad_spending, downloads)

# 3. 가중치(W)와 편향(b) 추출 및 출력
weight = model.coef_[0]      # 가중치 (기울기)
bias = model.intercept_      # 편향 (y절편)

print(f"광고비 가중치(W): {weight:.2f} (광고비 1단위 증가 시 다운로드 증가량)")
print(f"기본 편향(b): {bias:.2f} (광고비가 0일 때의 기본 다운로드 수)")

# 4. 광고비 40 지출 시 예측
target_spending = np.array([[40]])
predicted_downloads = model.predict(target_spending)

print(f"광고비 40(400만원) 지출 시 예측 다운로드 수: {predicted_downloads[0]:.1f}천 건")

