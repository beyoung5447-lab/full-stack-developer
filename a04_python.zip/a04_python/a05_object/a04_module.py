'''
# 모듈과 패키지
1. 파이썬에서 내가 만든 코드가 길어지거나, 남이 만든 훌륭한 코드를 가져다 쓰고 싶을 때
사용하는 패키지와 모듈(import) 개념입니다.
2. 방 안을 정리할 때, 종류별로 상자에 담아 라벨을 붙이듯, 파이썬 파일들도 폴더별로 깔끔하게
정리하고 필요할 때만 쏙쏙 뽑아 쓰는 방법을 재미있게 정리해봅시다.
3. 파이썬의 프로그래밍 체계(주소체계-마트료시카인형)
    1) 파이썬 프로젝트는 큰 상자 안에 작은 상자가 있고, 그 안에 또 내용물이 있는
    러시아 인형(마트료시카) 구조와 같습니다.
    - 프로젝트(Project) : 가장 큰 상자(예: 내 게임 프로그램 전체)
    - 패키지(Package) : 폴더(예: character_folder, item_folder)
    - 모듈(Module) : 파이썬 파일 .py (예: weapon.py, potion.py)
    - 구성요소:파일 안에 들어있는 변수, 함수, 클래스
    이때 다른 상자(파일)에 있는 기능을 내 상자로 가져와는 마법사의 키워드가 바로
    from과 import입니다. 너무 길면 as를 써서 내 맘대로 별명을 붙일 수도 있죠!!
4. 핵심 코드 : 외부 기능 가져오기
    1) 특정 파일에 변수 하나만 콕 집어서 가져오기
    from 폴더.파일 import 변수명
    2) 가져올 때 내 맘대로 짧은 별명(애칭) 붙여서 가져오기
    from 폴더.파일 import 원래이름 as 내맘대로별칭
    3) 파일 안에 있는 모든 것(*)을 한꺼번에 다 가져오기(가끔만 쓰세요!!)
    from 폴더.파일 import *
    - 택배를 주물할 때를 상상하면 프 임 애 라고 외워보세요
    프(from) : 어디서 보낼까요?(출처:폴더.파일)
    임(import) : 무엇을 보낼까요?(내용물:함수, 클래스, 변수)
    애(as) : 애칭(별명)은 뭘로 할까요?(너무 길 때 짧게 부르기)
5. 맛집 배달 앱 만들기
   우리가 soul_app이라는 폴더 안의 bakery.py 파일에 있는 빵(클래스)과 커피(함수)를
   우리집으로 배달시킨다고 상상해 봅시다.

   # 1. 빵집에서 크로와상 클래스 가져오기(이름이 길어서 별명 C_bread로 부르기)
   from a04_python.z02_seoul_app.bakery import Croissant as C_bread
   # 2. 빵집에서 커피 만드는 함수 그래도 가져오기
   from a04_python.z02_seoul_app.bakery import make_coffee

   # 3. 이제 우리 집(현재 파일)에서 마음껏 먹어봅시다.
   my_snack= C_Bread("초코 크로와사", 3500)
   my_snack.eat()

   # 함수 그대로 호출하기     
   make_coffee("아이스 아메리카노")  

'''
import sys
# 파이썬이 모듈을 찾을 때 최상위 프로젝트 폴더(a01_exp)를 기준으로 찾도록 경로 추가
sys.path.append(r"C:\a01_exp")

from a04_python.z02_seoul_app.bakery import Croissant as C_bread
from a04_python.z02_seoul_app.bakery import make_coffee
my_snack = C_bread("초코 크로와상", 3500)
my_snack.eat()
make_coffee("아이스 아메리카노")

from a04_python.a05_object.pck01.module01 import Person 
from a04_python.a05_object.pck01.module01 import callFunction as call
p01 = Person()
print('외부 패키지와 모듈에 있는 객체 호출:',p01.name)
# 외부 패키지 모듈 함수를 이름을 변경하여 호출
call()



