'''
# DTO(Data Transfer Object) : 순수 배달 상자(객체로 데이터 전송시 사용)
1. DTO는 계층 간(데이터베이스 <==> 화면, 함수 <==> 함수, 객체 <==> 객체)
   데이터 교환만을 위해 사용하는 객체입니다.
2. 복잡한 로직(계산, 판단) 없이 데이터(속성)만 가집니다.
3. 중국집 배달 철가방 : 철가방(DTO)의 목적은 짜장면(Data)을 주방에서 손님에게
   안전하게 운반하는 겁입니다. 철가방이 짜장면 맛을 보거나(로직 수행), 짜장면
   요리하지 않습니다. 오직 담아서 이동하는 것이 목표입니다.
4. 개념 풀이(암기를 위한)
   D(Data) - 오직 데이터만 싣는다
   T(Taxi) - 목적지까지 이동(Transfer)만 한다.
   O(Only) - 기능(메서드)은 없고 변수만 있다.
   DTO는 데이터만 태우는 택시입니다.
5. 기본 처리 형식
    from dataclasses import dataclass 
    - 내장된 dataclasses 모듈로부터 dataclass를 사용합니다.
    @dataclass 
    - 사용 처리할 객체를 annotation(- @ )으로 선언합니다.
    class XXXDTO:
        속성1:데이터유형
        속성2:데이터유형
        ex)
        title:str
        price:int
        클래스를 선언하고 속성과 데이터유형을 정의한다. 최신 DTO 선언형식
    
    위와 같이 클래스 선언하고
    참조변수 = XXXDTO("속성값1", 속성값2, 속성값3...) 
    형식으로 객체를 생성함과 동시에 속성값을 할당합니다.
    @dataclass에서 생성자를 자동으로 생성해 놓았기에 처리가 가능합니다.
    print(참조변수) 
    기본 내용을 패키지명.클래스명@16진수 주소값이지만, 위와 같은 DTO 클래스는
    내부적으로 default __repr__ 함수를 이용해서 객체명(속성=속성값,....)으로 
    선언하였기에 해당 객체를 구조를 명확히 알게 처리 해놓았다.
'''
from dataclasses import dataclass

@dataclass
class BookDTO:
    title: str # 속성명:데이터유형 str, int, float, bool
    price: int

bk1 = BookDTO("파이썬 기초", 25000)
bk2 = BookDTO("스프링 중급", 35000)
print(bk1)
print(bk2)
'''
# DTO의 list 처리
1. 위와같은 DTO을 일반적으로 실무환경에서 요청값을 전달하거나(검색 key 입력, 로그인 시 
  id, pwd입력시 전달 하는 등), DB 처리후, 2차원 데이터를 DTO에 담아서 처리하여, 화면에
  뿌려주는 경우가 많습니다.
  (DB처리 결과 ==> 반복문을 통해 list안에 DTO단일객체를 append() 메서드로 추가하여 처리
   ==> DTO list 배열을 화면에 테이블 형식으로 출력 처리 )
2. 사전 지식 점검
   1) list 배열 : 동적 배열 [] 형식으로 데이터를 추가/수정/삭제 할 수 있는 구조체입니다.
   2) append() : 위 list 배열에서 지원하는 메서드로 구성요소를 추가합니다.   
'''
@dataclass
class MemberDTO:
    nickname:str
    job:str

memList = [] # 리스트를 초기화.
memList.append(MemberDTO("지존검사","Warrior"))
memList.append(MemberDTO("다정힐러","Cleric"))
memList.append(MemberDTO("씨크궁수","Archer"))
# 리스트에 객체 하나씩을 append를 통해 담는 처리..
print(memList)
# for in 구문을 통해서 지정된 형식으로 출력
print('이    름\t직   업')
for member in memList:
    print(f'{member.nickname}\t{member.job}')

'''    
### 🌱 1단계: DTO 기초 설계 및 객체 생성 (초급)

* **문제 1-1:** `@dataclass`를 사용하여 카페 메뉴 데이터를 담는 
`CafeDTO` 클래스를 정의하세요. 속성으로는 메뉴 이름인 `menu_name`(문자열)과 가격인 `price`(정수)를 가집니다. (이때 `dataclasses` 모듈에서 `dataclass`를 불러오는 코드도 함께 작성하세요.)
* **문제 1-2:** 위에서 작성한 `CafeDTO`를 사용하여, 이름이 `"카페라떼"`이고 가격이 
`5000`인 객체를 생성하여 변수 `cafe1`에 할당한 뒤, `cafe1`을 화면에 그대로 출력하세요.
* **문제 1-3:** 영화 정보를 배달하기 위한 `MovieDTO` 클래스를 정의하세요. 
속성으로는 제목 `title`(문자열), 장르 `genre`(문자열), 평점 `score`(실수, float)를 가집니다.
* **문제 1-4:** 위에서 만든 `MovieDTO`를 사용하여 `("매트릭스", "SF", 9.8)` 
값을 가진 객체를 생성하고 `movie1` 변수에 담으세요. 
이번에는 객체 자체를 출력하지 말고, 점(`.`) 연산자를 활용하여 
`영화 매트릭스의 평점은 9.8점입니다.` 형태로 문장을 만들어 출력하세요.

---

### 🌿 2단계: DTO와 리스트(List)의 결합 (중급)

* **문제 2-1:** 게임 상점의 아이템 정보를 담을 `ItemDTO` 클래스를 작성하세요 (속성: `item_name` 문자열, `gold` 정수). 그 다음 빈 리스트인 `itemList`를 만들고, `append()` 메서드를 사용하여 세 개의 서로 다른 아이템 데이터(`"초보자의 검" 100`, `"마법의 지팡이" 500`, `"요정의 방패" 300`)를 DTO 객체로 생성해 리스트에 차례대로 추가하세요. 마지막으로 `itemList` 배열 자체를 출력해 보세요.

---

### 🌳 3단계: 리스트 순회 및 데이터 포맷팅 (고급)

* **문제 3-1:** 2단계에서 완성된 `itemList` 배열을 활용합니다. `for in` 반복문을 사용하여 리스트 안에 있는 아이템 객체들을 하나씩 꺼낸 뒤, 화면에 아래와 같이 데이터가 정돈된 표 형태로 출력되도록 코드를 작성하세요. (맨 윗줄에 탭(`\t`)을 활용한 제목줄을 먼저 출력해야 합니다.)
*(출력 예시 형태)*
```text
아이템명        가격(Gold)
초보자의 검     100
마법의 지팡이   500
요정의 방패     300

'''

# 문제 1-1
from dataclasses import dataclass

@dataclass
class CafeDTO:
    menu_name: str
    price: int

# 문제 1-2
cafe1 = CafeDTO("카페라떼", 5000)
print(cafe1) 
# 출력 결과: CafeDTO(menu_name='카페라떼', price=5000)

# 문제 1-3
@dataclass
class MovieDTO:
    title: str
    genre: str
    score: float

# 문제 1-4
movie1 = MovieDTO("매트릭스", "SF", 9.8)
# DTO 내부의 개별 속성(데이터)에 접근할 때는 참조변수.속성명 형식을 사용합니다.
print(f'영화 {movie1.title}의 평점은 {movie1.score}점입니다.')


from dataclasses import dataclass

@dataclass
class ItemDTO:
    item_name: str
    gold: int

itemList = [] # 빈 리스트 초기화

# append를 통해 DTO 객체를 생성함과 동시에 리스트에 추가합니다.
itemList.append(ItemDTO("초보자의 검", 100))
itemList.append(ItemDTO("마법의 지팡이", 500))
itemList.append(ItemDTO("요정의 방패", 300))


# 리스트 자체를 출력하면 리스트 대괄호 [] 안에 DTO 객체들이 쉼표로 구분되어 보입니다.
print(itemList)
print( itemList[0].item_name )
print( itemList[0].gold )

# 3단계는 2단계의 코드가 이미 실행되어 itemList에 데이터가 담겨있다는 가정하에 진행됩니다.
print("아이템명\t가격(Gold)") # \t는 탭(Tab) 띄어쓰기를 의미합니다.
for item in itemList:
    # item 변수에는 ItemDTO 객체가 하나씩 차례대로 담깁니다.
    print(f"{item.item_name}\t{item.gold}")

    