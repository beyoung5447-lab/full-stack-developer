'''
# 메서드
1. 클래스(Class)가 캐릭터를 만드는 설계도라면, 메서드(Method)는 그 캐릭터가 할 수 있는
행동(스킬)입니다.
2. 함수(def)와 똑같이 생겼지만, 클래스 안에서 살고 있다는 점이 다릅니다.
3. 가장 큰 특징은 첫 번째 매개변수로 무조건 self(나 자신)를 가진다는 것입니다. 내 체력을
깎고, 내 마나를 쓴다 라는 걸 명시하기 위해서죠
4. 메서드가 할 수 있는 일 4단계
   1) 단순 출력 : 내 이름은 @@다 외치기!!
   2) 매개변수 활용 : 입력받은 데이지 계산하기
   3) 상태(필드) 변경 : 내 체력(self.hp) 깎기, 돈(self.money)벌기
   4) 리턴(return)값 반환 : 사냥 후 얻은 경험치를 결과로 돌려주기
5. 핵심 코드 : 메서드의 기본 생김새
   class Character:
       # 1. 생성자(초기 상태 설정)
       def __init__(self, name):
           self.name = name
           self.hp = 100
       # 2. 기능 메서드 (스킬)
       def attack(self, power):
           print(f"{self.name}이(가) {power}의 파워로 공격합니다.")
       # 3. 상태 변경 및 리턴 메서드
       def heal(self, amount):
           self.hp +=amount # 내 체력(self.hp) 증가!!
           return self.hp
6. 핵심 개념 정리
    메서드를 만들 때, 자꾸 괄호 안을 헷갈리신다면, 다음 내용으로 기억해보세요
    메셀매리!!
    - 메(메서드) : def 로 메서드를 만들 땐
    - 셀(self) : 무조건 괄호 첫 번째에 self부터 쓴다!(안 쓰면 에러 폭발)
    - 매(매개변수) : 필요한 재료(데이터)는 self 뒤에 쉼표(,)를 찍고 받는다.
    - 리(return) : 계산이 끝날 결과는 return으로 돌려준다.
'''
class Character:
    def __init__(self, name):
        self.name = name
        self.hp = 100
    def attack(self, power):
        print(f"{self.name}이(가) {power}의 파워로 공격합니다.")
    def heal(self, amount):
        self.hp += amount
        return self.hp
    def showInfo(self):
        print("# 캐릭터 현상태 정보 #")
        print(f"이름:{self.name}")
        print(f"체력:{self.hp}")
# 1. 객체 생성 : 두 캐릭터 만들기
hero = Character("전사")
mage = Character("마법사")
hero.showInfo()
mage.showInfo()
hero.attack(30)
mage.attack(50)
# 2. 몬스터의 반격으로 체력이 깍였다고 가정해봅시다.
hero.hp = 50
mage.hp -= 40
hero.showInfo()
mage.showInfo() 
# 3. 힐링 포션을 사용해서 체력 회복..
current_hp = hero.heal(20)
print("리턴된 hero의 현재 체력:", current_hp)
'''
굴릴수록 커지는 '눈사람' 클래스 만들기
아래의 [요구사항]을 읽고, 비어있는 Snowman 클래스 내부를 직접 채워보세요.

[요구사항]

클래스 이름: Snowman

초기화 (__init__): 처음 눈뭉치의 크기(self.size)는 10으로 설정합니다.

눈 굴리기 (roll 메서드): 매개변수 snow를 받아서, 내 눈뭉치 크기에 더해줍니다(누적).

눈 녹기 (melt 메서드): 매개변수 없이, 내 눈뭉치 크기에서 5를 빼줍니다(감소).

크기 확인 (check_size 메서드): 현재 내 눈뭉치 크기(self.size)를 리턴(return) 합니다.

'''
class Snowman:
    # 1. 초기 상태 설정
    def __init__(self, size=10):
        self.size = size
        print("초기:",self.size)
    # 2. 눈굴리기
    def roll(self, snow):
        self.size += snow
        print("눈굴리기!")
    # 3. 눈녹이기
    def melt(self):
        self.size -= 5
        print("눈녹이기!")
    # 4. 크기확인 (size 리턴)
    def check_size(self):
        return self.size    

my_snow = Snowman()
my_snow.roll(10)
my_snow.roll(20)
my_snow.roll(30)
my_snow.melt()
my_snow.melt()
final_size = my_snow.check_size()
print("최종 마지막 크기:", final_size)