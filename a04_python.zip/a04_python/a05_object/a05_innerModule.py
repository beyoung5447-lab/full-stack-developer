'''
# 내장 모듈
1. 파이썬에서 사용되는 내장 모듈을 단계별로 진행하겠습니다.
    1) math 모듈 : 수학적 함수
       수학적 연산을 위한 다양한 함수를 제공합니다.
    2) 사용방법과 기본 형식
       import math  # 내장 모듈 사용시 선언 방법
       num = 25
       # 제곱근 계산 방법
       sqrt = math.sqrt(num)
'''
import math 
num = 25
sqrt = math.sqrt(num)
print(f'{num}의 제곱근은 {sqrt}!!')
# 팩토리얼
print(f'5의 패토리얼 {math.factorial(5)}')
# random 모듈 - 난수를 생성하거나 임의의 값을 선택할 때, 사용
import random
# 1~10 사이의 임의의 정수
rand_int = random.randint(1,10)
print("임의의 정수(1~10범위내):", rand_int)
# 리스트(배열)에서 임의의 항목 선택
items = ['사과','바나나','딸기','오렌지']
print(f'선택한 임의의 과일은 {random.choice(items)}')
# 리스트 항목 섞기
cards = ['♣A','♣2','♣3','♣4','♣5','♣6','♣7','♣8','♣9','♣10','♣J','♣Q','♣K']
# 위 리스트 내용을 섞기(순서를 임의로 만들어 겹치지 않게 하기)
random.shuffle(cards)
print("섞은 후, 카드 :", cards)
# datetime 모듈 : 날짜와 시간 처리
# 1. 일반적으로 파이썬에 사용되는 날짜와 시간을 처리하는 모듈
import datetime
# 현재 날짜와 시간
now = datetime.datetime.now()
print(f'현재 날짜와 시간(기본 형식):{now}')
# 지정된 형식 설정
formatted_date = now.strftime('%Y-%m-%d %H:%M:%S')
# '%Y : 년도 -%m : 월  -%d 일  %H 시간:%M 분 :%S 초
print(f'지정된 형식의 날짜로 오늘 현재 날짜와 시간을 출력:{formatted_date}')
# 지정한 특정 날싸 설정
specific_date = datetime.datetime(2026, 12, 31)
print("특정 날짜 지정:", specific_date)
'''
🌱 1단계: 초급 (단일 기능 사용)
파이썬 내장 모듈의 기본적인 함수들을 호출해 보는 단계입니다.

문제 1-1: math 모듈을 사용하여 숫자 225의 제곱근을 구하고 출력하세요.
'''
# 진행 코드


'''
문제 1-2: math 모듈을 사용하여 숫자 7의 팩토리얼 값을 구하고 출력하세요.
'''
# 진행 코드


'''
문제 1-3: random 모듈을 사용하여 1부터 100 사이의 임의의 정수를 하나 생성하고 출력하세요.
'''
# 진행 코드


'''
문제 1-4: ['봄', '여름', '가을', '겨울'] 리스트를 만들고, random 모듈을 사용하여 이 중 무작위로 하나의 계절을 선택해 출력하세요.
'''
# 진행 코드


'''
문제 1-5: datetime 모듈을 사용하여 현재 시스템의 날짜와 시간을 가져와서 기본 형식 그대로 출력하세요.
'''
# 진행 코드


'''
문제 1-6: datetime 모듈을 사용하여 2030년 1월 1일을 특정 날짜 객체로 생성하고 출력하세요.
'''
# 진행 코드


'''
import math
import random
import datetime

# 문제 1-1
sqrt_val = math.sqrt(225)
print(f"225의 제곱근: {sqrt_val}")

# 문제 1-2
fac_val = math.factorial(7)
print(f"7의 팩토리얼: {fac_val}")

# 문제 1-3
rand_num = random.randint(1, 100)
print(f"1~100 사이 임의의 정수: {rand_num}")

# 문제 1-4
seasons = ['봄', '여름', '가을', '겨울']
choice_season = random.choice(seasons)
print(f"선택된 계절: {choice_season}")

# 문제 1-5
now = datetime.datetime.now()
print(f"현재 날짜와 시간: {now}")

# 문제 1-6
target_date = datetime.datetime(2030, 1, 1)
print(f"특정 날짜 생성: {target_date}")

🌿 2단계: 중급 (데이터 조작 및 응용)
생성된 데이터를 변형하거나 두 가지 이상의 개념을 조합하는 단계입니다.

문제 2-1: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10] 리스트를 만들고 random 모듈로 무작위로 섞으세요. 그 후, 섞인 리스트에서 앞의 3개 숫자만 잘라내어(슬라이싱) 출력하세요.
'''
# 진행 코드


'''
문제 2-2: datetime 모듈을 사용하여 현재 시간을 가져온 뒤, strftime을 사용하여 YYYY년 MM월 DD일 AM/PM HH시 MM분 형식(예: 2026년 10월 19일 AM 10시 25분)으로 출력하세요. (%p와 %I 포맷 코드 활용)
'''
# 진행 코드


'''
문제 2-3: random 모듈을 사용하여 10부터 50 사이의 임의의 정수를 하나 생성하세요. 그리고 math 모듈의 원주율 상수(math.pi)를 불러와 생성된 정수와 곱한 결과를 소수점 둘째 자리까지 반올림(round 함수 사용)하여 출력하세요.
'''
# 진행 코드


'''
import math
import random
import datetime

# 문제 2-1
numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
random.shuffle(numbers)
picked_numbers = numbers[:3]
print(f"섞은 후 선택된 3개의 숫자: {picked_numbers}")

# 문제 2-2
now = datetime.datetime.now()
# %p: AM/PM, %I: 12시간제 시간
formatted_now = now.strftime('%Y년 %m월 %d일 %p %I시 %M분')
print(f"포맷팅된 현재 시간: {formatted_now}")

# 문제 2-3
rand_val = random.randint(10, 50)
calc_result = rand_val * math.pi
rounded_result = round(calc_result, 2)
print(f"생성된 숫자({rand_val}) * 파이의 결과: {rounded_result}")

🌳 3단계: 고급 (복합 모듈 통합 및 시나리오 구현)
실제 프로그램에서 자주 쓰이는 논리를 구현하는 단계입니다.
문제 3-1 (로또 번호 생성기): 1부터 45까지의 숫자가 들어있는 리스트를 만들거나 범위(range)를 지정하세요. random 모듈을 사용하여 중복되지 않는 6개의 숫자를 무작위로 추출한 뒤, 번호를 오름차순으로 정렬하여 출력하세요. (random.sample을 사용하거나 shuffle 후 슬라이싱 활용)
'''
# 진행 코드


'''
문제 3-2 (D-Day 계산기): datetime 모듈을 사용하여 오늘 날짜를 구하세요. 그리고 datetime.timedelta 기능을 사용하여 오늘로부터 정확히 '100일 뒤'의 날짜를 계산한 후, YYYY-MM-DD 형태로 출력하세요.
'''

import random
import datetime

# 문제 3-1: 로또 번호 생성기
# random.sample을 사용하면 리스트에서 중복 없이 지정된 개수를 추출할 수 있습니다.
lotto_numbers = list(range(1, 46))
selected_lotto = random.sample(lotto_numbers, 6)
selected_lotto.sort() # 오름차순 정렬
print(f"생성된 로또 번호: {selected_lotto}")

# 문제 3-2: D-Day 계산기
now = datetime.datetime.now()
# timedelta를 사용하여 특정 기간을 더하거나 뺄 수 있습니다.
after_100_days = now + datetime.timedelta(days=100)
formatted_dday = after_100_days.strftime('%Y-%m-%d')
print(f"오늘부터 100일 뒤 마감일: {formatted_dday}")