'''
# 생성자(Constructor)
1. 생성자란 객체(물건)를 처음 생성할 때, '무조건,자동으로' 딱 한 번 실행되는 마법의 함수입니다.
2. 붕어빵을 틀에서 찍어낼 때, 팥을 넣을지 슈크림을 넣을지 처음부터 결정하고 세팅하는 과정과 같습니다
3. 생성자의 가장 중요한 역할은 만들어진 객체의 기본 상태나 특징(속성)을 처음으로 설정(초기화)해 주는 것입니다.
4. 만약 개발자가 생성자를 명시적으로 만들지 않으면, 파이썬이 알아서 내용이 없는 '기본생성자(Default Constructor)
   를 몰래 만들어 실행해 줍니다.
5. 생성자를 만드는 기본 공식
   1) 파이썬에서 생성자의 이름은 무조건 앞뒤로 밑줄 두 개를 붙인 __init__으로 고정되어 있습니다.
      init는 초기화라는 뜻하는 initilize의 약자입니다.
      가장 기본형태 : def __init__(self): - 넘겨받는 재료가 없을 때
      재료를 받는 형태 : def __init(self, name, age, loc) : - 이름, 나이, 지역 등 재료를 넘겨받을 때
      객체 생성 방식 : 객체명 = 클래스명('홍길동', 25,'서울') 처럼 클래스 이름 뒤 괄호 값을 넣으면
          생성자가 이 값들을 쏙 빨아들입니다.
   2) 속성(특징)을 즉석에서 만들어주는 생성자
      파이썬은 매우 유연해서, 클래스 위쪽에 변수를 미리 적어두지 않아도 됩니다.
      생성자 안에 self.속성명 = 값이라고 적는 순간, 그 객체 만의 고유한 특징이 바로 만들어집니다.
      예를 들어, 수박 객체를 만들 때 def __init__(self) 안에 self.size="10KG", self.taste="시원하고 단맛"
      이라고 적어두면, 생성된 수박은 기본적으로 10kg에 단맛을 가지게 됩니다.
6. 파이썬만의 특별한 비법
   1) 파이썬에서는 이름이 같은 생성자를 여러 개 만들 수 없습니다. 대신 훨씬 강력한 기본값(default) 매개변수 
      기능을 제공합니다.
      매개변수를 선언할 때 def __init__(self, name="미할당", price=0, cnt=1) 처럼 미리 기본값을 정해둘 수 
      있습니다.
      사용자가 값을 넘겨주면 넘겨준 값으로 덮어쓰고, 아무 값도 안 넣고 객체를 만들면 우리가 정해둔 기본값으로
      알아서 똑똑하게 채워집니다.
      이를 활용하여 여행사 프로그램에서 출발지를 기본 서울로 해두고, 변경이 필요할 때만 값을 입력받도록 유연하게
      설계할 수 있습니다.
   2) 무한대 보따리(가변 매개변수)
      상자에 과일을 2개 담을지, 10개 담을지 미리 알 수 없다면 어떻게 할까요? 이때는 변수 앞에 별표(*)를 하나 붙여
      주면 됩니다.
      def __init__(self, *prods): 라고 선언하면, 객체를 만들 때 입력한 모든 값을 변하지 않는 묶음(튜플)형태로
      한번에 받아냅니다.
      Box("사과","바나나")를 넣든, Box("컴퓨터","핸드폰", "TV")를 넣든 상관없이 알아서 개수에 맞게 상자에 쏙
      담깁니다.
      이후 반복문(for문)을 사용하면 상자에 담긴 물건이나 그룹에 속한 학생들의 이름을 차례대로 쉽게 꺼내어 볼 수
      있습니다.

'''
# 기본 생성자 호출
class Fruit:
    name = None
    # 선언하지 않지만 처리가 된다. 내부적으로 __init__(self) 가 있기에 이것을 default 생성자라고 합니다.

f1 = Fruit()
f1.name ="사과"

# 사용자 정의 생성자 선언.
class Apple:
    def __init__(self):
        print("사과 객체 생성~~ 주소값:", self)

a1 = Apple()
a2 = Apple()
a3 = Apple()
# ex) 매개변수가 없는 생성자 선언 - Car 클래스를 매개변수 없는 생성자를 선언하고, 자동차 객체라고 
# 출력하는 내용을 선언하고, 객체를 3개 생성해보세요
class Car:
    def __init__(self):
        print("자동차 객체, 주소값:", self) 
c1 = Car()        
c2 = Car()        
c3 = Car()  

print("생성자를 통한 객체 생성 후, 해당 c1변수에 의한 주소:", c1)

# 매개변수가 없는 생성자를 통해서 초기값을 설정..
class Orange:
    def __init__(self):
        self.kind = "맛난 오렌지"
        self.price = 3000

o1 = Orange()
o2 = Orange()
o3 = Orange()
print("두번째 Orange 객체의 가격 확인:", o2.price)
o1.kind="노랑 오렌지"
o3.price = 4000

print("# 변경 이후 속성 확인 #")
print(o1.kind, o1.price)
print(o2.kind, o2.price)
print(o2.kind, o3.price)
# ex) WaterMellon 클래스를 선언하고, 기본생성자에 의해 size(10kg), taste(시원하고 단맛)
#    으로 초기값을 할당 한 후,  객체를 생성 후, 초기값을 확인(w1이름으로 객체생성), 
#    w2이름으로 객체 생성은 속성값을 변경 후, 확인하세요..
class WaterMellon:

    
    def __init__(self):
        self.size = "10kg"
        self.taste = "시원하고 단맛"

w1 = WaterMellon()
print("w1의 size:", w1.size)
print("w1의 taste:", w1.taste)
w2 = WaterMellon()
print("w2의 size:", w2.size)
w2.size="30kg"
w2.taste="이국적인 맛"
print("w2의 size:", w2.size)
print("w2의 size:", w2.taste)
# 매개변수에 default값 설정..(객체 생성하면서 기본값과 추가변된 값을 바로 설정하는 경우)
class Product:
    def __init__(self, name="미할당", price=0, cnt=1):
        self.name = name
        self.price = price
        self.cnt = cnt
    def show(self):
        print("# 물건정보 출력 #")
        print(f'물건명:{self.name}')
        print(f'가격:{self.price}')
        print(f'갯수:{self.cnt}')
p1 = Product()  # 아무런 매개변수 없을 때
p1.show() 
p2 = Product("사과")  # 아무런 매개변수 없을 때
p2.show()    
p3 = Product("바나나",4000)  # 아무런 매개변수 없을 때
p3.show()       
p4 = Product("오렌지",2000, 5)  # 아무런 매개변수 없을 때
p4.show() 
p5 = Product(price=5000)  # 특정하게 매개변수 속성 지정해서 처리할 때, 그외는 default 설정
p5.show() 
'''
나만의 카페 주문 시스템 만들기
아래의 [조건]을 읽고, 주석으로 표시된 부분에 코드를 작성하여 Coffee 클래스를 완성해 보세요. 
하단의 테스트 코드가 에러 없이 예상 결과처럼 출력되면 성공입니다!
[조건]
클래스 이름: Coffee
매개변수와 기본값 (__init__ 메서드):
음료명(name): 기본값 "아메리카노"
사이즈(size): 기본값 "Tall"
가격(price): 기본값 3000
출력 메서드 (show_order 메서드):
호출 시 음료명, 사이즈, 가격이 보기 좋게 출력되도록 만드세요.

'''
class Coffee:
    def __init__(self, name="아메리카노", size="Tall", price=3000):
        self.name = name
        self.size = size
        self.price = price
    def show_order(self):
        print("# 주문한 음료 #")
        print(f'음료명:{self.name}')
        print(f'사이즈:{self.size}')
        print(f'가격:{self.price}')

or1 = Coffee()
or1.show_order()
or2 = Coffee("카페라떼")
or2.show_order()
or3 = Coffee("유자차", "small")
or3.show_order()
or4 = Coffee("마키야또", "그란떼", 4500)
or4.show_order()
or5 = Coffee(size="Venti", price=3500)
or5.show_order()









