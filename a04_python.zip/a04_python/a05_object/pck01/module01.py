class Person:
    name = '홍길동'

def callFunction():
    print("모듈호출 성공!!")
# ex) a04_module.py 에서 현재 이 패키지에 있는 모듈의 클래스를 호출하고,
# 함수도 호출하여 사용하게 하세요..
    