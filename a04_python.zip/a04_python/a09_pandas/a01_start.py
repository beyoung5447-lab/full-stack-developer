'''
파이썬 데이터 분석 기초: Pandas (Series와 DataFrame)

[1. 개요]
이번 시간에는 파이썬 데이터 분석의 핵심 라이브러리인 판다스(Pandas)의 기본 자료구조를 알아봅니다.
실무에서 엑셀처럼 데이터를 다루기 위해 반드시 알아야 하는 Series(시리즈)와 DataFrame(데이터프레임)의 
개념을 이해하고,데이터를 생성, 조회, 수정, 삭제하는 전체적인 흐름을 실습해 보겠습니다.

[2. 전문용어로 정확한 핵심 개념]

* Pandas(판다스): 정형 데이터를 효율적으로 조작하고 분석하기 위한 파이썬 표준 라이브러리입니다.
    ps) 정형(행/열 - 2차원), 비정형(파일안에 정형화되지 않는 데이터, text, 이미지, ..), 반정형(json {key:value}) 
* Series(시리즈): 인덱스(Index)와 값(Values)으로 구성된 1차원 배열(1D Array) 형태의 자료구조입니다.
* DataFrame(데이터프레임): 행(Row/Index)과 열(Column)로 구성된 2차원 관계형 데이터(2D Relational Data) 구조입니다.
* Attribute(속성): 데이터 객체가 가진 고유한 특성을 의미합니다. (예: shape, columns, index, values, T)
* loc(Label-location): 인덱스 라벨(이름)을 기반으로 데이터프레임의 특정 행과 열에 직접 접근하는 메서드입니다.
* drop: 지정한 축(axis)을 기준으로 행이나 열을 제거하며, inplace 인자를 통해 원본 반영 여부를 결정합니다.

[3. 좀 더 쉽고 재미있는 핵심 키워드/코드 최고의 암기법]

* Series 암기법: "Series는 엑셀의 '하나의 열(Column)'이다!" (1줄 기차)
코드: pd.Series([데이터리스트], index=[이름표])
* DataFrame 암기법: "DataFrame은 엑셀의 '시트(Sheet)' 전체다!"
코드: pd.DataFrame({컬럼명: [데이터들]}) -> 딕셔너리의 Key가 지붕(컬럼)이 됩니다.
* DataFrame 속성 5총사 암기법 (데이터를 하나의 건물에 비유하기):
* shape: 건물의 덩치 (건물이 몇 층(행)이고 방이 몇 개(열)인지?)
* columns: 지붕 간판 (건물의 1호라인, 2호라인 등의 열 이름)
* index: 각 층의 문패 (행 이름, 입주자 이름)
* values: 건물 안의 실제 사람들 (껍데기를 뗀 순수 데이터 배열)
* T (Transpose): 건물을 옆으로 눕히기 (행과 열 맞바꾸기)


* 데이터 조작 암기법:
* 콕 집어 바꾸기: df.loc['행이름', '열이름'] = 바꿀값 (정확히 좌표를 찍고 덮어쓰기)
* 통째로 열 추가: df['새로운열'] = 값 (딕셔너리에 새로운 키를 추가하듯 쉽게 적용)


* 데이터 삭제 drop() 암기법:
* axis=0: 위에서 아래로 떨어지는 폭탄 피하기 -> '행(Row)' 삭제 (기본값)
* axis=1: 옆에 세워진 기둥 베어내기 -> '열(Column)' 삭제
* inplace=True: 문서 작업 후 '진짜 저장(Ctrl+S)' 버튼 누르기!

# 설치
pip install pandas

python -m pip install pandas

python -m pip install openpyxl

'''
import pandas as pd
# 1. Series 만들기 (간식 가격)
snacks = pd.Series([1500,3000,2000,1000])
print(snacks)
# 기본적으로 0부터 시작하는 index가 붙고, 데이터가 리스트되면 각 데이터 유형에 맞게 dtype이 표현되는
# 구조를 확인할 수 있다.
# 2. 지정된 index로 Series 만들기(우리반의 MBTI 분석 10, 5, 7)
mbti_counts = pd.Series({"INFP":10, "ENEJ":5, "ISTP":7})
print(mbti_counts)
'''
# 인덱스를 지정하기
1. Series 에는 따로 지정하지 않으면 자동으로 0, 1, 2, 3.. 번호표가 붙습니다.
2. 이 번호표 대신 특정한 인덱스 이름 붙이기
    pd.Series(데이터리스트, index = [인덱스 이름,......]
    pd.Series({인덱스:값, 인덱스:값,....})
    
'''
# 3. 데이터와 인덱스를 따로 설정한 Series 만들기( 카페 메뉴 )
cafe_menu = pd.Series([4500, 5000, 5500], index=['아메리카노', '라떼','스무디'])
print(cafe_menu)
print("라떼의 가격:", cafe_menu['라떼'])
print("인덱스만 따로 출력:", cafe_menu.index)
print("값만 따로 출력:", cafe_menu.values)

'''
[초급] PC방 알바생의 재고 및 판매량 관리 (배운 내용 모두 포함)
당신은 인기가 많은 PC방의 매니저입니다. 오늘 하루 동안의 판매 데이터를 Pandas Series로 깔끔하게 정리해 봅시다.
오늘 시간대별로 팔린 컵라면 개수를 리스트로 만들어 Series를 생성하세요. (자동 인덱스 부여)
데이터: [15, 22, 18, 30]
PC방 좌석별 최고 인기 게임 장르의 접속자 수를 딕셔너리로 만들어 Series를 생성하세요.
데이터: {"AOS": 45, "RPG": 20, "FPS": 35}
인기 간식의 가격표를 데이터 리스트와 인덱스 리스트를 따로 지정하여 Series로 만드세요.
데이터: [2500, 3500, 2000] / 인덱스: ['신라면', '소시지', '콜라']
위에서 만든 가격표에서 '소시지'의 가격만 콕 집어서 출력해 보세요.
가격표 Series에서 메뉴 이름(index)들만 따로, 가격(values)들만 따로 추출하여 출력해 보세요.
'''
import pandas as pd

# 1. 리스트만 사용하여 Series 만들기 (자동 0, 1, 2, 3 인덱스)
ramen_sales = pd.Series([15, 22, 18, 30])
print("1. 시간대별 컵라면 판매량:\n", ramen_sales)

# 2. 딕셔너리를 사용하여 Series 만들기 (키값이 인덱스가 됨)
game_users = pd.Series({"AOS": 45, "RPG": 20, "FPS": 35})
print("\n2. 장르별 접속자 수:\n", game_users)

# 3. 데이터와 인덱스를 각각 리스트로 지정하여 만들기
snack_prices = pd.Series([2500, 3500, 2000], index=['신라면', '소시지', '콜라'])
print("\n3. PC방 간식 가격표:\n", snack_prices)

# 4. 특정 인덱스의 값 접근하기
print("\n4. 소시지의 가격:", snack_prices['소시지'])

# 5. 인덱스와 값 따로 추출하기
print("5. 메뉴 이름만 따로(index):", snack_prices.index)
print("5. 가격만 따로(values):", snack_prices.values)

'''
[중급] 직장인 김대리의 요일별 식비 분석 (응용)
김대리는 이번 주 평일(월~금) 동안 쓴 점심 식비를 Pandas Series로 관리하려고 합니다. 배운 내용을 조금 더 응용해 봅시다.

식비 데이터와 요일 인덱스를 각각 리스트로 지정하여 Series를 만드세요.

데이터: [12000, 15000, 8000, 25000, 10000] / 인덱스: ['월', '화', '수', '목', '금']

가장 지출이 컸던 회식 다음 날, '목'요일의 식비가 얼마인지 인덱스 이름으로 접근해 출력하세요.

(응용) .values 속성을 이용해 김대리가 이번 주 평일에 쓴 '총 식비(합계)'를 구하세요. (힌트: 파이썬 기본 함수 sum() 활용)

(응용) .index 속성을 이용해 식비를 지출한 요일 명단만 추출해 보세요.

'''


import pandas as pd

# 1. 요일별 식비 Series 생성
lunch_costs = pd.Series([12000, 15000, 8000, 25000, 10000], index=['월', '화', '수', '목', '금'])
print("1. 요일별 식비 지출 내역:\n", lunch_costs)

# 2. 특정 인덱스(목요일) 값 출력
print("\n2. 회식 다음 날 목요일의 식비:", lunch_costs['목'])

# 3. .values를 활용한 총합 계산 (values는 배열 형태이므로 sum() 함수 적용 가능)
total_cost = sum(lunch_costs.values)
print("\n3. 이번 주 총 식비 합계:", total_cost)

# 4. .index를 활용한 요일 명단 추출
print("\n4. 식비 지출 요일 명단:", lunch_costs.index)