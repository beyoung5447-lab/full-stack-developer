'''
# Pandas를 통한 데이터 입출력(I/O) 완벽 마스터

## 1. 개요: 데이터 분석의 시작과 끝

데이터 분석가는 훌륭한 요리사와 같습니다. 아무리 좋은 분석 기법(레시피)이 있어도, 
냉장고에서 재료를 제대로 꺼내오고(Load)
완성된 요리를 안전한 용기에 담아 보관하는(Save) 과정이 필수적입니다.
이번 시간에는 Pandas를 활용해 외부 데이터를 DataFrame이라는 도마 위로 불러오고,
가공된 데이터를 다시 파일로 깔끔하게 저장하는 데이터 입출력(I/O) 기술을 다룹니다.

---

## 2. 전문 용어로 알아보는 정확한 핵심 개념

데이터를 파일에서 읽고 쓰는 핵심 함수와 반드시 알아야 할 필수 옵션들입니다.

1. **데이터 입력 (Input / Load)**
* 외부 파일(.csv, .xlsx)을 Pandas의 DataFrame 객체로 메모리에 적재합니다.
* `pd.read_csv('파일명.csv')`: 쉼표로 구분된 텍스트 형식의 데이터를 불러옵니다.
* `pd.read_excel('파일명.xlsx')`: 엑셀 스프레드시트 데이터를 불러옵니다. 
(주의: `openpyxl` 라이브러리 설치 필요)


2. **데이터 출력 (Output / Save)**
* 가공이 완료된 DataFrame 객체를 다시 디스크의 파일 형태로 기록합니다.
* `df.to_csv('파일명.csv')`: 데이터를 CSV 파일로 내보냅니다.
* `df.to_excel('파일명.xlsx')`: 데이터를 엑셀 파일로 내보냅니다.


3. **입출력 핵심 파라미터 (Options)**
* `index=False`: 저장 시 DataFrame의 숫자형 인덱스(0, 1, 2...)를 제외합니다.
* `encoding='utf-8'`: 한글 데이터가 깨지지 않도록 표준 문자 인코딩을 강제합니다. 
(윈도우 환경 엑셀은 간혹 'cp949' 사용)
* `index_col='열이름'`: 데이터를 불러올 때, 특정 열을 DataFrame의 행 인덱스로 즉시 지정합니다.
* `sheet_name='시트명'`: 엑셀 저장 시 엑셀 하단의 워크시트 이름을 명시적으로 지정합니다.

## 3. 재미있는 핵심 키워드와 최고의 암기법

* **Read는 냉장고 열기, To는 타파웨어에 담기**
* 가져올 때는 `read_...` (데이터를 읽어라!), 내보낼 때는 `to_...` (~파일로 만들어라!)로 직관적으로 기억하세요.


* **index=False : "쓸데없는 대기표는 버려주세요!"**
* 이 옵션 없이 데이터를 저장하고 다시 불러오면 `Unnamed: 0`이라는 정체불명의 인덱스 열이 좀비처럼 계속 늘어납니다.
* "파일 저장할 때는 언제나 `index=False`가 국룰이다"라고 기계적으로 암기하셔도 좋습니다.


* **CSV는 빠르고 가볍게, Excel은 보고용으로 예쁘게**
* 실무에서 대용량 데이터는 무조건 CSV로 주고받으며, 최종 보고서를 경영진에게 넘길 때만 Excel 형식을 사용합니다.



'''
'''
# 스타트업 VIP 고객 명단 관리(CSV 입출력)
신규 런칭한 서비스의 초기 VIP 유저 명단을 빠르고 가벼운 CSV 파일로 백업하고 확인해 봅시다.

'''
import pandas as pd
import os
# 현재 실행 중인 파이썬 스크립트 파일의 폴더 경로 가져오기
current_dir = os.path.dirname(os.path.abspath(__file__))
# 저장할 파일의 정확한 절대 경로 생성 (현재 폴더 경로 + 파일명)
file_path = os.path.join(current_dir, "z10_members.csv")
# 1. VIP 명단 데이터 생성
vip_data ={
    "회원 아이디":["USER_01","USER_002","USER_003"],
    "가입 경로":["앱스토어","인스타그램","지인추천"],
    "총결제액":[150000,320000,45000]
}
df_vip = pd.DataFrame(vip_data)
# 2. CSV 파일로 안전하게 저장하기(대기표 제외, 한글 깨짐 방지)
df_vip.to_csv(file_path,index=False, encoding="utf-8")
print("VIP 명단 CSV 백업 완료")
'''
[초급 문제] 동네 카페 마감 재고 관리 (현재 경로에 안전하게 저장하기)
상황:
당신은 잘나가는 '위즈덤 카페'의 매니저입니다. 오늘의 마감 재고 데이터를 안전하게 CSV 파일로 백업하려고 합니다.
위에서 배운 파일 입출력과 경로 지정 코드를 활용하여 문제를 해결해 보세요.

조건:

다음 데이터를 사용하여 DataFrame을 생성하세요.

품목: ["원두", "우유", "바닐라시럽"]

남은수량: [5, 12, 3]

단가: [20000, 3000, 15000]

os 모듈을 사용하여 현재 파이썬 스크립트가 실행되는 동일한 폴더에 z11_coffee_stock.csv라는 이름으로 저장하세요.

쓸데없는 숫자 인덱스(대기표)는 빼고, 한글이 깨지지 않도록 UTF-8 인코딩을 적용하세요.

'''
import pandas as pd
import os

# 1. 카페 재고 데이터 생성
stock_data = {
    "품목": ["원두", "우유", "바닐라시럽"],
    "남은수량": [5, 12, 3],
    "단가": [20000, 3000, 15000]
}
df_stock = pd.DataFrame(stock_data)

# 2. 현재 스크립트 경로 가져오기 및 파일 경로 생성
current_dir = os.path.dirname(os.path.abspath(__file__))
file_path = os.path.join(current_dir, "z11_coffee_stock.csv")

# 3. CSV 파일로 안전하게 저장하기 (인덱스 제외, 한글 깨짐 방지)
df_stock.to_csv(file_path, index=False, encoding="utf-8")
print(f"카페 재고 CSV 백업 완료: {file_path}")


'''
[중급 문제] 스타트업 게임 유저 등급 분류 및 동적 폴더 백업
상황:
신규 런칭한 모바일 게임의 유저 데이터를 분석 중입니다. 단순히 현재 폴더에 저장하는 것을 넘어,
데이터를 가공한 후 별도의 백업 전용 폴더를 자동으로 생성하여 그 안에 파일을 저장하는 실무 자동화 스크립트를 작성하세요.

조건:

아래 유저 데이터를 DataFrame으로 만드세요.

유저ID: ["Hero", "Mage", "Archer"]

플레이시간(시간): [120, 45, 200]

과금액(원): [50000, 0, 150000]

데이터 가공: '플레이시간'이 100 이상인 유저는 'VIP', 그렇지 않은 유저는 '일반' 값을 가지는 '유저등급' 열을 추가하세요.

경로 자동화: 현재 스크립트 경로 아래에 backup_data라는 이름의 하위 폴더를 만드세요.
(단, 프로그램을 여러 번 실행해도 에러가 나지 않도록 이미 폴더가 존재하면 무시하도록 처리하세요.)

생성된 backup_data 폴더 안에 가공된 데이터를 z12_user_class.csv로 저장하세요. (인덱스 제외, UTF-8 필수)
'''



import pandas as pd
import os

# 1. 게임 유저 데이터 생성
game_data = {
    "유저ID": ["Hero", "Mage", "Archer"],
    "플레이시간": [120, 45, 200],
    "과금액": [50000, 0, 150000]
}
df_game = pd.DataFrame(game_data)

# 2. '유저등급' 열 추가 (리스트 컴프리헨션 활용)
# 플레이시간이 100 이상이면 VIP, 아니면 일반으로 분류
df_game["유저등급"] = ["VIP" if time >= 100 else "일반" for time in df_game["플레이시간"]]

# 3. 현재 경로 아래 'backup_data' 폴더 생성 및 파일 경로 설정
current_dir = os.path.dirname(os.path.abspath(__file__))
backup_dir = os.path.join(current_dir, "z13_backup_data")

# 폴더가 없으면 생성 (exist_ok=True 옵션으로 기존 폴더가 있어도 에러 방지)
os.makedirs(backup_dir, exist_ok=True)

# 저장할 최종 절대 경로 완성 (backup_data 폴더 내부)
file_path = os.path.join(current_dir, "z12_user_class.csv")

# 4. CSV 파일로 안전하게 저장하기
df_game.to_csv(file_path, index=False, encoding="utf-8")
print(f"유저 등급 분류 데이터 백업 완료: {file_path}")