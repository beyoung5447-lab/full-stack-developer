'''
주문번호: ["ORD-001", "ORD-002", "ORD-003"]
상품명: ["무선 기계식 키보드", "노이즈캔슬링 이어폰", "대용량 보조배터리"]
수량: [2, 1, 3]

        주문번호   상품명               수량
    0   ORD-001   무선 기계식 키보드    2
    1   ORD-002   노이즈캔슬링 이어폰   1
    2   ORD-003   대용량 보조배터리     3

            주문번호   상품명               수량
    물건1   ORD-001   무선 기계식 키보드    2
    물건2   ORD-002   노이즈캔슬링 이어폰   1
    물건3   ORD-003   대용량 보조배터리     3    

# 온라인 쇼핑몰 당일 발송 명단 z06_shipping_list.csv 저장..

'''
import pandas as pd
import os
# 1. 데이터 프레임 만들기
#    1) dictionary  {"컬럼명":[....],"컬럼명2":[....]}
#    2) pd.DataFrame( dict )
shipping_data = {
    "주문번호":["ORD-001", "ORD-002", "ORD-003"],
    "상품명":["무선 기계식 키보드", "노이즈캔슬링 이어폰", "대용량 보조배터리"],
    "수량":[2, 1, 3]
}
#df_shipping = pd.DataFrame(shipping_data, index=["물건1","물건2","물건3"])
df_shipping = pd.DataFrame(shipping_data)
print(df_shipping)
# 2. 파일 경로 설정하기
#    현재 스트립트(소스코드) 경로 가져오기 및 파일 경로 생성..
current_dir = os.path.dirname(os.path.abspath(__file__))
print("현재 운영체제에서 실행하는 파일(a04_fileData.py)이 있는 경로:", current_dir)
#    현재에 저장할 실제 파일 선언(현재경로, 파일정보)..
file_path = os.path.join(current_dir,"z14_shipping.csv")
print(file_path)

# 3. csv 파일로 안정하게 저장하기(인덱스 제외, 한글 깨짐 방지)
#    데이터프레임명.to_csv(저장할파일(경로+파일), index=True/False, encoding="utf-8")
df_shipping.to_csv(file_path, index=False, encoding="utf-8")
