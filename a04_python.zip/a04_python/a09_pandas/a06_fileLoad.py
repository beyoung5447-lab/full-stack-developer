import pandas as pd
import os

# 1. 현재 파이썬 스크립트의 절대 경로가 포함된 폴더 위치 가져오기
current_dir = os.path.dirname(os.path.abspath(__file__))

# 2. 현재 폴더 경로와 불러올 파일명 결합하기
file_path = os.path.join(current_dir, "z02_top_secret.csv")

# 3. CSV 파일을 읽어서 DataFrame 객체로 메모리에 로딩하기
df_sales = pd.read_csv(file_path)

# 4. 제대로 로딩되었는지 데이터프레임 내용 전체 출력하기
print("로딩된 최고 비밀 내용:\n", df_sales)