'''
# 엑셀 파일 다루기와 옵션 활용
1. 엑셀로 저장하기
    1) sheet_name 옵션으로 시트 이름도 정해줄 수 있어요
    df.to_excel("파일명", index=False, sheet_name="시트이름")
2. 옵션을 써서 불러오기
    1) index_col="메뉴" : 메뉴 컬럼을 인덱스(행 이름)으로 쓰겠다..
    df_excel = pd.read_excel("파일명", index_col="메뉴")
    2) 볼러온 데이터 확인
        df_excel.loc['컬럼1','컬럼2',...]

# 영업팀 월간 지출 결의서 작성(Excel 입출력)
팀원들이 사용한 법인카드 내역을 엑셀로 정리하여 재무팀에 제출해야 합니다.
특정 항목을 인덱스로 잡아서 깔끔하게 불러오는 법을 확인합니다.
'''
import pandas as pd
import os
# 1. 현재 파이썬 스크립트의 절대 경로가 포함된 폴더 위치 가져오기
current_dir = os.path.dirname(os.path.abspath(__file__))

# 2. 현재 폴더 경로와 불러올 파일명 결합하기
file_path = os.path.join(current_dir, "z20_expense.xlsx")

expense_data = {
    "항목":["클라이언트 식대","팀 회식","택시비"],
    "금액":[120000,250000,15000],
    "승인자":["강팀장","김팀장","이대리"]
}
df_expense = pd.DataFrame(expense_data)
print(df_expense)
df_expense.to_excel(file_path, index=False, sheet_name="11월 지출 내역서")
print("지출 결의서 엑셀 저장 완료!!")

# 3. 엑셀 파일 불러올 때 특정 열('항목')을 인덱스로 지정하여 구조화하기..
df_excel_loaded = pd.read_excel(file_path, index_col="항목")
print("[재무팀 확인용] 불러온 엑셀 데이터:\n", df_excel_loaded)
print("총 지출 금액:", df_excel_loaded['금액'].values)
print("총 지출 금액:", df_excel_loaded['금액'].sum(),"원")
'''
# a08_excelExp.py
[초급 문제] 계란자조금관리위원회 월간 납부 현황 엑셀 자동화(a08_excelExp.py)
상황:
계란자조금관리위원회의 IT 인프라를 담당하는 당신은, 이번 달 산란계 농가들의 자조금 납부 내역을 엑셀로 정리해
엄혜란 담당자에게 전달해야 합니다. 파이썬을 이용해 데이터를 엑셀로 저장하고, 다시 불러와 총액을 계산해 보세요.

조건:

다음 데이터를 사용하여 DataFrame을 생성하세요.

농가명: ["행복농장", "푸른초원", "다산양계"]

납부금액: [500000, 350000, 800000]

납부상태: ["완납", "미납", "완납"]

현재 스크립트와 동일한 폴더에 z21_egg_fund.xlsx 파일로 저장하되, 시트 이름은 "11월 납부현황"으로 지정하세요.
(인덱스는 제외할 것)

저장된 엑셀 파일을 다시 읽어올 때, 특정 열('농가명')을 인덱스로 지정하여 데이터프레임을 구조화하세요.

재무팀 확인용으로 불러온 데이터를 출력하고, 11월 총 납부금액의 합계(sum())를 구해 출력하세요.

'''
import pandas as pd
import os

# 1. 현재 파일 경로 확보 및 파일명 결합
current_dir = os.path.dirname(os.path.abspath(__file__))
file_path = os.path.join(current_dir, "z21_egg_fund.xlsx")

# 2. 계란자조금 납부 현황 데이터프레임 생성
fund_data = {
    "농가명": ["행복농장", "푸른초원", "다산양계"],
    "납부금액": [500000, 350000, 800000],
    "납부상태": ["완납", "미납", "완납"]
}
df_fund = pd.DataFrame(fund_data)
print("--- [저장 전] 작성된 납부 현황 데이터 ---")
print(df_fund)

# 3. 엑셀 파일로 안전하게 저장 (대기표 제외, 시트명 명시)
df_fund.to_excel(file_path, index=False, sheet_name="11월 납부현황")
print("\n✅ 계란자조금 납부 현황 엑셀 저장 완료!!")

# 4. 엑셀 파일 불러오기 ('농가명'을 행 인덱스로 즉시 지정)
df_loaded = pd.read_excel(file_path, index_col="농가명")
print("\n--- [재무팀 확인용] 불러온 엑셀 데이터 ---")
print(df_loaded)

# 5. 총 납부 금액 합산하여 출력
total_fund = df_loaded["납부금액"].sum()
print(f"\n💰 11월 총 납부 금액: {total_fund:,} 원")

'''
[중급 문제] 위즈덤 온라인 글로벌 드랍쉬핑 순이익 분석 및 백업 파이프라인
상황:
'위즈덤 온라인'의 쇼피파이(Shopify) 스토어에서 글로벌 결제가 발생했습니다. 제품 판매가에서 매입원가를 제외한
순이익을 계산한 뒤, 회계 감사용 폴더를 따로 만들어 엑셀로 백업하세요. 그 후 데이터를 다시 로딩해 검증합니다.

조건:

아래 데이터를 활용해 DataFrame을 생성하세요.

주문번호: ["US-001", "JP-002", "UK-003", "KR-004"]

판매가: [120000, 85000, 150000, 45000]

매입원가: [80000, 60000, 95000, 30000]

데이터 가공: 판매가에서 매입원가를 뺀 '순이익' 열을 데이터프레임에 새롭게 추가하세요.

경로 자동화: 현재 폴더 아래에 finance_reports라는 폴더를 생성하세요. (존재 시 에러 무시)

생성된 폴더 안에 z22_global_sales.xlsx 파일명으로 저장하세요. 시트명은 "글로벌매출_요약"입니다.

저장 직후, 해당 엑셀 파일을 다시 로딩하되 '주문번호'를 인덱스로 지정하여 불러오세요.

불러온 데이터 프레임을 출력하고, 오늘 발생한 총 순이익의 합계를 계산해 콤마(,)가 포함된 포맷으로 출력하세요.

'''

import pandas as pd
import os

# 1. 글로벌 드랍쉬핑 매출 데이터 생성
sales_data = {
    "주문번호": ["US-001", "JP-002", "UK-003", "KR-004"],
    "판매가": [120000, 85000, 150000, 45000],
    "매입원가": [80000, 60000, 95000, 30000]
}
df_sales = pd.DataFrame(sales_data)

# 2. 데이터 가공: 판매가 - 매입원가로 '순이익' 컬럼 생성
df_sales["순이익"] = df_sales["판매가"] - df_sales["매입원가"]

# 3. 'finance_reports' 하위 폴더 생성 및 저장할 엑셀 절대 경로 완성
current_dir = os.path.dirname(os.path.abspath(__file__))
report_dir = os.path.join(current_dir, "finance_reports")
os.makedirs(report_dir, exist_ok=True)
file_path = os.path.join(report_dir, "z22_global_sales.xlsx")

# 4. 가공된 데이터를 엑셀로 백업 저장 (인덱스 제외)
df_sales.to_excel(file_path, index=False, sheet_name="글로벌매출_요약")
print(f"✅ 위즈덤 온라인 재무팀 보고용 엑셀 백업 완료: {file_path}")

# 5. 저장된 엑셀 파일을 검증하기 위해 로딩 ('주문번호'를 행 인덱스로 지정)
df_loaded = pd.read_excel(file_path, index_col="주문번호")
print("\n--- 📊 불러온 재무 데이터 (주문번호 기준 구조화) ---")
print(df_loaded)

# 6. 총 순이익 계산 및 천 단위 콤마 포맷팅 출력
total_profit = df_loaded["순이익"].sum()
print(f"\n💎 금일 글로벌 판매 총 순이익: {total_profit:,} 원")